-- luajit mod/tests/test_loadprogress.lua  (the status bar's loading line after a teleport)
local T = dofile((arg[0]:match('^(.*)[/\\]') or '.') .. '/testlib.lua')
local L = require('guadeloupeEarth/loadprogress')
T.check(L.line(0, {}) == nil and not L.active(), 'no load: no line')
L.start(10)
T.check(L.line(10, { placed = false }) == 'Loading the ground', 'from the teleport request: the ground first')
local prog = { roads = { 34, 52 }, trees = { 10, 40 }, far = { 120, 405 } }
local line = L.line(15, { placed = true, progress = prog, pending = {} })
T.check(line == 'Loading 33%  |  roads & buildings 34/52  ·  trees 10/40  ·  distant land 120/405',
  'each part done / wanted, the share over all of them (ground + parts): ' .. tostring(line))
line = L.line(16, { placed = true, progress = { roads = { 52, 52 }, trees = { 40, 40 }, far = { 400, 405 } },
  pending = { roads = 3 } })
T.check(line:find('roads & buildings 52/52', 1, true) and line:find('distant land 400/405', 1, true)
  and not line:find('trees', 1, true), 'a part whose tiles are all in but still being placed stays; a finished one goes')
local withGround = L.line(17, { placed = true, progress = { ground = { 0, 1 }, roads = { 52, 52 }, trees = { 40, 40 },
  far = { 405, 405 } }, pending = {} })
T.check(withGround == 'Loading 99%  |  ground', 'the ground still to be replaced (graded block, full photo): listed '
  .. tostring(withGround))
local done = { ground = { 1, 1 }, roads = { 52, 52 }, trees = { 40, 40 }, far = { 405, 405 } }
T.check(L.line(20, { placed = true, progress = done, pending = {} }) == 'Loading 100%', 'all in: 100 %')
T.check(L.line(21, { placed = true, progress = done, pending = { trees = 1 } }):find('trees', 1, true),
  'something new comes: listed again')
T.check(L.line(22, { placed = true, progress = done, pending = {} }) == 'Loading 100%', 'in again')
T.check(L.line(24.9, { placed = true, progress = done, pending = {} }) == 'Loading 100%', 'not yet QUIET_S')
T.check(L.line(25.1, { placed = true, progress = done, pending = {} }) == nil and not L.active(), 'quiet for QUIET_S: over')
L.start(30)
T.check(L.line(31, { placed = true, progress = nil, pending = {} }) == 'Loading 99%', 'no counts yet: still loading')
T.check(L.line(30 + L.MAX_S + 1, { placed = false }) == nil and not L.active(), 'never longer than MAX_S')
L.start(1000)
T.check(L.line(1001, { placed = true, progress = { roads = { 0, 0 }, trees = { 0, 0 }, far = { 9, 9 } }, pending = {} })
  == 'Loading 100%', 'parts with nothing wanted (trees off) count as done')
L.reset()
T.check(not L.active(), 'reset')
T.done('test_loadprogress')
