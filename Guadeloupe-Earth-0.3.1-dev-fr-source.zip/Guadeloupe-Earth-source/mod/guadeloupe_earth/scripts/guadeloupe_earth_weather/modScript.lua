-- Real weather for Guadeloupe Earth (separate from the core extension; see lua/ge/extensions/guadeloupeEarth/weather.lua).
setExtensionUnloadMode('guadeloupeEarth_weather', 'manual')
