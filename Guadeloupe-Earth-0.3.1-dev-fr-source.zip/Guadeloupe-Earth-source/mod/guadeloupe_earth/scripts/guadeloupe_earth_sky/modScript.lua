-- Real-world sky for Guadeloupe Earth (separate from the core extension; see lua/ge/extensions/guadeloupeEarth/sky.lua).
setExtensionUnloadMode('guadeloupeEarth_sky', 'manual')
