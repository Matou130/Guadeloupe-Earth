// Guadeloupe Earth's settings: the schema, the presets and the state shared by the settings pages (the pause menu's
// Guadeloupe Earth tab: EarthSettingsPage.vue per page, EarthSettingsSide.vue beside them; and the full page
// EarthSettings.vue, a route of its own for the main menu). One state for all of them (this module is loaded once):
// the setting pointed at in a page shows its help in the side card. Lua side: lua/ge/extensions/guadeloupeEarth/settings.lua.
import { ref, computed } from "vue"

// Mirrors lua/ge/extensions/guadeloupeEarth/settings.lua SCHEMA (the Lua side validates and clamps). Sections down the
// left; Graphics first (the quality presets: settings.lua PRESETS).
export const settingsSchema = [
  {
    name: "Graphismes",
    presets: true,
    intro: "Choisissez un préréglage, puis ajustez les options ci-dessous. Les changements s’appliquent immédiatement, sauf la résolution de la photo du sol, qui prend effet au prochain chargement du niveau.",
    items: [
      { id: "framePacing", type: "bool", default: true, name: "Régularité des images", desc: "Stabilise le temps entre les images pour éviter les à-coups pendant le chargement du monde. Cela réduit d’environ un septième le nombre d’images par seconde durant le chargement. Désactivez cette option pour privilégier la fréquence d’images." },
      { id: "terrainDetail", type: "select", default: "normal", name: "Détail du terrain", desc: "Détermine jusqu’où les reliefs détaillés sont dessinés. Faible : collines plus grossières et environ 20 % d’éléments en moins. Élevé, Ultra et Extrême : montagnes et côtes plus précises au loin. Extrême génère environ deux fois plus d’éléments lointains et demande plus de temps au chargement.",
        options: [ { label: "Faible", value: "low" }, { label: "Normal", value: "normal" }, { label: "Élevé", value: "high" }, { label: "Ultra", value: "ultra" }, { label: "Extrême", value: "extreme" } ] },
      { id: "groundPhoto", type: "select", default: "2048", name: "Résolution de la photo du sol", desc: "Netteté de la photo aérienne et des routes peintes au sol (carrés de 1 km). 1024 : 1 m par pixel, idéal pour les appareils portables. 2048 : 0,5 m, valeur par défaut. 4096 : 0,25 m, bords de route les plus nets, mais chaque carré demande plus de calcul et quatre fois plus de mémoire vidéo.",
        note: "S’applique au prochain chargement du niveau.",
        options: [ { label: "1024 (léger)", value: "1024" }, { label: "2048 (par défaut)", value: "2048" }, { label: "4096 (très net)", value: "4096" } ] },
      { id: "trees", type: "select", default: "normal", name: "Densité des arbres", desc: "Nombre d’arbres et de buissons visibles à chaque distance. Faible : forêts moins denses et meilleures performances. Ultra et Extrême : davantage d’arbres au loin, pour les cartes graphiques puissantes.",
        options: [ { label: "Faible", value: "low" }, { label: "Moyenne", value: "medium" }, { label: "Normale", value: "normal" }, { label: "Élevée", value: "high" }, { label: "Ultra", value: "ultra" }, { label: "Extrême", value: "extreme" } ] },
      { id: "treeDistance", type: "select", default: "normal", name: "Distance d’affichage des arbres", desc: "Distance d’affichage des arbres, rochers, poteaux et objets au bord des routes : environ 1,3 km en mode Normal, 1 km en Proche et 2,8 km au maximum. Une plus grande distance utilise davantage de mémoire et de puissance graphique.",
        options: [ { label: "Proche", value: "near" }, { label: "Moyenne", value: "medium" }, { label: "Normale", value: "normal" }, { label: "Lointaine", value: "far" }, { label: "Très lointaine", value: "farther" }, { label: "Maximum", value: "max" } ] },
      { id: "buildingDistance", type: "select", default: "normal", name: "Distance d’affichage des bâtiments", desc: "Distance d’affichage des bâtiments et des ponts. En mode Normal, les bâtiments lointains simples apparaissent jusqu’à 1,6 km et les grands bâtiments jusqu’à 4,8 km. Les bâtiments proches sont toujours affichés en détail.",
        options: [ { label: "Proche", value: "near" }, { label: "Normale", value: "normal" }, { label: "Lointaine", value: "far" }, { label: "Maximum", value: "max" } ] },
      { id: "objectDetail", type: "select", default: "game", name: "Détail des objets", desc: "Distance à laquelle les arbres, bâtiments, accessoires et véhicules passent de leurs modèles détaillés à des modèles simplifiés, dans le monde Guadeloupe Earth. « Réglage du jeu » reprend la qualité des maillages de BeamNG. Les niveaux supérieurs sollicitent davantage la carte graphique.",
        options: [ { label: "Réglage du jeu", value: "game" }, { label: "Faible", value: "low" }, { label: "Normal", value: "normal" }, { label: "Élevé", value: "high" }, { label: "Ultra", value: "ultra" }, { label: "Extrême", value: "extreme" } ] },
      { id: "grass", type: "select", virtual: true, default: "normal", name: "Herbe et broussailles", desc: "Herbe et broussailles en 3D près du véhicule, avec les plantes du jeu. Désactivées, elles améliorent les performances des appareils portables. Sans le correctif facultatif pour Linux, le jeu régénère l’herbe dans une image plus lente chaque fois que le sol se déplace.",
        options: [ { label: "Désactivées", value: "off" }, { label: "Faibles", value: "low" }, { label: "Normales", value: "normal" }, { label: "Élevées", value: "high" } ] },
      { id: "grassDistance", type: "select", default: "normal", name: "Distance d’affichage de l’herbe", desc: "Portée de l’herbe en 3D (environ 50 à 70 m en mode Normal). Une plus grande portée affiche davantage de brins et augmente le temps de régénération lorsque le sol se déplace.", showIf: c => c.groundCover !== false,
        options: [ { label: "Proche", value: "near" }, { label: "Normale", value: "normal" }, { label: "Lointaine", value: "far" } ] },
      { id: "rocks", type: "bool", default: true, name: "Rochers", desc: "Affiche les rochers et les blocs sur les terrains nus, rocheux ou escarpés. Désactivez cette option pour les retirer, y compris leurs collisions." },
      { id: "nightLights", type: "select", default: "normal", name: "Éclairage des lampadaires", desc: "Nombre de lampadaires proches qui éclairent réellement la route la nuit. Les lampadaires éloignés restent visibles. Moins de lampes améliore les performances nocturnes.",
        options: [ { label: "Peu", value: "few" }, { label: "Normal", value: "normal" }, { label: "Beaucoup", value: "many" } ] },
      { id: "viewDistanceMode", type: "select", default: "horizon", name: "Distance de vue", desc: "Horizon réel : le terrain s’étend jusqu’à l’horizon. Distance fixe : la vue s’arrête à la limite indiquée ci-dessous, ce qui convient mieux aux appareils moins puissants.",
        options: [ { label: "Horizon réel", value: "horizon" }, { label: "Distance fixe", value: "fixed" } ] },
      { id: "viewDistanceKm", type: "float", min: 20, max: 1000, step: 10, default: 100, name: "Distance de vue fixe (km)", desc: "Distance maximale visible lorsque le mode Distance fixe est activé.", showIf: c => c.viewDistanceMode === "fixed" },
    ],
  },
  {
    name: "Monde",
    items: [
      { id: "networkMode", type: "choice", default: "auto", name: "Connexion Internet", desc: "Le mode automatique utilise Internet lorsque la connexion est disponible et revient aux données déjà en cache si elle ne l’est pas. Le mode En ligne autorise les téléchargements. Le mode Hors ligne bloque les requêtes Internet et utilise uniquement les données déjà téléchargées.",
        options: [ { label: "Automatique", value: "auto" }, { label: "En ligne", value: "online" }, { label: "Hors ligne", value: "offline" } ] },
      { id: "skyMode", type: "select", default: "real", name: "Soleil et étoiles", desc: "Temps réel : le soleil, la lune et les étoiles suivent l’heure et la date locales. Manuel : utilisez les commandes Temps et météo du jeu. Si vous changez l’heure dans le menu Pause, le mode Manuel s’active automatiquement.",
        note: "Un changement d’heure dans le menu Pause active le mode Manuel.",
        options: [ { label: "Temps réel", value: "real" }, { label: "Manuel", value: "manual" } ] },
      { id: "weatherMode", type: "select", default: "real", name: "Météo", desc: "Réelle : nuages, brouillard, vent, pluie, neige et température suivent la météo locale. Manuelle : utilisez les commandes Temps et météo du jeu. Tout changement de météo dans le menu Pause ou par un autre mod active le mode Manuel.",
        note: "Un changement de météo dans le menu Pause active le mode Manuel.",
        options: [ { label: "Météo réelle", value: "real" }, { label: "Manuelle", value: "manual" } ] },
      { id: "clouds", type: "bool", default: true, name: "Nuages", desc: "Affiche une couche de nuages volumétriques qui suit le terrain sous le véhicule." },
      { id: "realGravity", type: "bool", default: true, name: "Gravité réelle", desc: "Applique la gravité locale, qui varie légèrement selon la latitude, l’altitude et le relief. Désactivée, la gravité reste à 9,81 m/s²." },
      { id: "roads", type: "bool", default: true, name: "Routes", desc: "Affiche les routes, ponts et bâtiments réels issus d’OpenStreetMap et d’Overture. Désactivée, seule la forme du terrain est affichée." },
      { id: "highwaySigns", type: "bool", default: true, name: "Panneaux autoroutiers", desc: "Affiche les sorties, les destinations suspendues, les avertissements de fusion et les bornes kilométriques présents dans OpenStreetMap. Nécessite l’option Routes." },
      { id: "rebaseDistance", type: "float", min: 2000, max: 16000, step: 100, default: 15000, name: "Distance de recentrage (m)", desc: "Option avancée. Distance parcourue avant que l’origine du monde soit discrètement replacée sous le véhicule afin de préserver la précision physique. À 15 km, la précision est d’environ 1 mm." },
    ],
  },
  {
    name: "Interface",
    items: [
      { id: "statusBar", type: "bool", default: true, name: "Barre d’état", desc: "Barre en haut de l’écran indiquant la rue et la ville, la progression du chargement et la fréquence d’images." },
      { id: "placeNamesOnline", type: "bool", default: true, name: "Noms des lieux (en ligne)", desc: "Recherche les noms de villes, régions et pays affichés dans la barre d’état avec Photon de komoot. La position envoyée est arrondie à environ 1 km." },
      { id: "hudVisible", type: "bool", default: false, name: "Fenêtre d’état", desc: "Affiche la fenêtre compacte Guadeloupe Earth avec l’état de connexion, la position, le chargement et des boutons rapides. Contrôle aussi son ouverture au début du niveau." },
      { id: "dashboardSatellite", type: "bool", default: true, name: "Carte satellite sur le tableau de bord", desc: "Affiche la carte satellite Guadeloupe Earth sur les tableaux de bord compatibles. Désactivée, la page d’origine du véhicule est utilisée." },
      { id: "creditsVisible", type: "bool", default: true, name: "Crédits des données à l’écran", desc: "Indique dans un coin les sources des images, du relief et de la météo. Activés par défaut, car plusieurs licences exigent une attribution visible. Masqués dans le menu Pause et sur la grande carte." },
      { id: "creditsCorner", type: "select", default: "bottom-left", name: "Emplacement des crédits", desc: "Coin de l’écran où afficher les crédits des données.", showIf: c => c.creditsVisible !== false,
        options: [ { label: "En bas à gauche", value: "bottom-left" }, { label: "En bas à droite", value: "bottom-right" }, { label: "En haut à gauche", value: "top-left" }, { label: "En haut à droite", value: "top-right" } ] },
      { id: "creditsSize", type: "select", default: "small", name: "Taille des crédits", desc: "Taille du texte des crédits des données.", showIf: c => c.creditsVisible !== false,
        options: [ { label: "Petite", value: "small" }, { label: "Normale", value: "normal" } ] },
    ],
  },
  {
    name: "Multijoueur",
    items: [
      { id: "beammpOnLaunch", type: "bool", default: true, name: "Lancer BeamMP avec Guadeloupe Earth", desc: "L’application Guadeloupe Earth lance BeamMP avec le jeu pour activer le multijoueur facultatif. Cette préversion ne dispose pas d’annuaire public : connectez-vous directement à un serveur compatible. Le réglage prendra effet au prochain lancement de l’application." },
      { id: "beammpLauncher", type: "path", what: "beammp", name: "Lanceur BeamMP", placeholder: "Chemin du lanceur BeamMP ou de son dossier", desc: "Lanceur BeamMP utilisé par l’application : celui que vous avez choisi ou, à défaut, celui qui a été détecté. Le bouton Parcourir ouvre la fenêtre de fichiers du système. Vous pouvez aussi saisir ou coller un chemin, puis cliquer sur Utiliser. Le réglage prendra effet au prochain lancement." },
    ],
  },
  {
    name: "Stockage",
    items: [
      { id: "cacheUsage", type: "info", name: "Cache des téléchargements", desc: "Relief, images et données cartographiques comptabilisés ici. Les tuiles de routes et du monde générées sont conservées séparément entre les sessions." },
      { id: "cacheCapGb", type: "number", default: 0, min: 0, unit: "Go", name: "Limite du cache (Go)", desc: "Limite de stockage du relief, des images et des données cartographiques téléchargés. La valeur 0 signifie sans limite. Les tuiles de routes et du monde générées sont conservées séparément. L’espace disque disponible reste la limite pratique." },
      { id: "routeDownload", type: "select", default: "ahead", name: "Téléchargements sur l’itinéraire GPS", desc: "Lorsqu’un itinéraire GPS est calculé, son relief, ses routes et ses bâtiments peuvent être téléchargés en arrière-plan pour accélérer le trajet. À l’avance : les 20 prochains kilomètres. Itinéraire complet : jusqu’à 480 km. Pour conserver aussi les photos aériennes, utilisez Précharger l’itinéraire dans le panneau GPS de la carte.",
        options: [ { label: "Désactivés", value: "off" }, { label: "À l’avance (20 km)", value: "ahead" }, { label: "Itinéraire complet", value: "route" } ] },
      { id: "cacheDir", type: "path", what: "cache", name: "Dossier du cache", placeholder: "Dossier des téléchargements ou valeur par défaut", desc: "Emplacement du cache des téléchargements, par exemple sur un autre disque. Parcourir ouvre la fenêtre de fichiers du système. Vous pouvez aussi saisir un chemin et cliquer sur Utiliser. Par défaut, le dossier .cache/guadeloupe-earth est dans votre dossier utilisateur. Le changement prendra effet au prochain lancement ; déplacez d’abord les anciens fichiers pour les conserver." },
      { id: "cacheClear", type: "action", name: "Vider le cache des téléchargements", desc: "Supprime les données téléchargées de relief et d’images. Les tuiles générées de routes et du monde sont conservées." },
    ],
  },
  {
    name: "Retours",
    items: [
      { id: "reportOpen", type: "feedback", what: "report", label: "Signaler", name: "Signaler un problème ou une idée", desc: "Ferme cette page, prend une capture d’écran et recueille la position, la fréquence d’images, le matériel et les réglages graphiques. Choisissez ensuite le type de signalement, donnez-lui un titre et décrivez le problème. Un fichier issue.md prêt à publier est créé. Raccourci en jeu : Ctrl+Maj+E." },
      { id: "profilerOpen", type: "feedback", what: "profiler", label: "Démarrer le profilage", name: "Analyse des performances", desc: "Ferme cette page et enregistre pendant 30 secondes les temps d’image et les saccades pendant la conduite, avec leur position. La fenêtre de signalement des performances s’ouvre ensuite. Raccourci en jeu : Ctrl+Maj+Y." },
      { id: "reportPost", type: "text", name: "Publier un signalement", desc: "Après l’enregistrement, la fenêtre affiche le dossier du rapport et ouvre la page GitHub de création d’un problème. Modifiez issue.md et ajoutez screenshot.jpg au signalement." },
    ],
  },
  {
    name: "À propos",
    items: [
      { id: "connection", type: "info", name: "Application compagnon", desc: "Connexion à l’application Guadeloupe Earth (127.0.0.1:47613), qui génère le monde, et identifiant de session attribué à ce jeu." },
      { id: "anchor", type: "info", name: "Origine du monde", desc: "Origine actuelle du monde et latitude/longitude. Le recentrage replace cette origine sous le véhicule." },
      { id: "player", type: "info", name: "Votre position", desc: "Latitude, longitude et distance par rapport à l’origine du monde." },
      { id: "weather", type: "info", name: "Données météo", desc: "Météo réelle fournie par Open-Meteo.com, actualisée toutes les 10 minutes ou tous les 25 km." },
      { id: "gravity", type: "info", name: "Gravité", desc: "Gravité appliquée : valeur réelle (WGS84 et EGM2008) ou gravité normale selon la latitude." },
      { id: "deshadow", type: "info", name: "Correction des ombres", desc: "Éclairage corrigé des ombres intégrées aux photos aériennes." },
      { id: "colormatch", type: "info", name: "Raccord des images", desc: "Correction des différences de couleur entre les prises de vue aériennes." },
      { id: "credits", type: "text", name: "Crédits affichés", desc: "Sources des données actuellement visibles autour de vous." },
      { id: "attribution", type: "text", name: "Sources des données", desc: "Crédits des sources de relief et d’images utilisées." },
    ],
  },
  {
    name: "Développeur",
    devPresets: true,
    items: [
      { id: "tint", type: "dev", name: "Couleur des niveaux LOD", desc: "Colorie chaque tuile lointaine selon son niveau : vert pour le niveau du sol physique, cyan L0, bleu L1, violet L2, puis orange à rouge pour les niveaux plus grossiers. Session en cours uniquement." },
      { id: "outlines", type: "dev", name: "Contours des tuiles", desc: "Trace les contours des tuiles proches et les colore selon leur niveau ou leur état. Session en cours uniquement." },
      { id: "loading", type: "dev", name: "Visualisation du chargement", desc: "Fait clignoter les tuiles en attente et numérote les dix prochains imports dans leur ordre de chargement. Session en cours uniquement." },
      { id: "physics", type: "dev", name: "Bloc physique", desc: "Affiche le carré de terrain avec collision, celui en attente et les carrés de préparation et de validation du suivi du terrain. Session en cours uniquement." },
      { id: "physicsTerrain", type: "dev", name: "Afficher le terrain physique", desc: "Rend visible le terrain physique invisible pour le comparer aux tuiles affichées. Session en cours uniquement." },
      { id: "rings", type: "dev", name: "Rayons et zones", desc: "Affiche les portées de détail, de recentrage et de préchargement, ainsi que la zone du terrain lointain. Session en cours uniquement." },
      { id: "probe", type: "dev", name: "Vérification sous le véhicule", desc: "Compare le sol physique à la tuile visible sous le véhicule. La ligne devient rouge si le niveau est incorrect ou si l’écart dépasse 5 cm. Session en cours uniquement." },
      { id: "stats", type: "dev", name: "Panneau de statistiques", desc: "Affiche les temps d’image, le budget du régulateur, les imports et suppressions par seconde, la file d’attente, les objets, les erreurs et la charge du serveur. Session en cours uniquement." },
      { id: "graphs", type: "dev", name: "Panneau de graphiques", desc: "Trace sur 60 secondes le temps d’image, la longueur de la file d’attente, les imports par seconde et la vitesse. Session en cours uniquement." },
      { id: "map", type: "dev", name: "Mini-carte de diagnostic", desc: "Vue de dessus des tuiles autour de vous. Cliquez sur une tuile pour l’inspecter. Session en cours uniquement." },
      { id: "controls", type: "dev", name: "Panneau de commandes", desc: "Commandes des superpositions, gel du LOD, recentrage forcé, budget de diffusion et mode du ciel. Session en cours uniquement." },
      { id: "log", type: "dev", name: "Journal des événements", desc: "Affiche les 50 derniers événements du mod : validation du terrain, recentrages, erreurs et état. Session en cours uniquement." },
      { id: "devOutlineKm", type: "float", min: 0.5, max: 20, step: 0.5, default: 3, name: "Portée des contours (km)", desc: "Distance maximale d’affichage des contours de tuiles et de la visualisation du chargement." },
      { id: "devMapKm", type: "float", min: 1, max: 80, step: 1, default: 10, name: "Portée de la mini-carte (km)", desc: "Zoom initial de la mini-carte." },
    ],
  },
]

// Each page's icon (the pause menu's side buttons take the icon's name, LayoutMenu's tabs the icon) and its button id
// (the first keeps the old Mods-tab button's id: settings.lua M.BUTTON_ID, pageExists)
export const PAGE_ICONS = { Graphismes: "eyeOutlineOpened", Monde: "globe", Interface: "cogOutline",
  Multijoueur: "peopleOutline", Stockage: "floppyDisk", Retours: "bug", "À propos": "info", Développeur: "code" }
export const pageId = (name, i) => i === 0 ? "guadeloupeEarth-settings" :
  "guadeloupeEarth-settings-" + name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")

// The quality presets' cards (settings.lua PRESETS: what each sets)
export const qualityPresets = [
  { id: "low", name: "Faible", short: "Forêts clairsemées, sans herbe, vue à 40 km", desc: "Pour les ordinateurs portables anciens et les cartes graphiques modestes : moins d’arbres et de bâtiments proches, pas d’herbe, terrain lointain simplifié, photo du sol légère (1024), peu de lampadaires et vue limitée à 40 km." },
  { id: "medium", name: "Moyen", short: "Forêts allégées, herbe légère", desc: "Forêts un peu moins denses et plus proches, herbe légère, peu de lampadaires et horizon réel. Préréglage conseillé pour Steam Deck." },
  { id: "high", name: "Élevé", short: "Rendu complet", desc: "Arbres, bâtiments, terrain et herbe en qualité normale, tous les lampadaires et horizon réel. C’est le rendu de Guadeloupe Earth avant l’ajout des préréglages." },
  { id: "ultra", name: "Ultra", short: "Forêts plus denses et plus lointaines", desc: "Forêts plus denses et lointaines, bâtiments plus éloignés, terrain lointain plus précis, herbe fournie et davantage de lampadaires. Pour les cartes graphiques puissantes." },
  { id: "extreme", name: "Extrême", short: "Tous les réglages au maximum", desc: "Tous les réglages au maximum jusqu’à l’horizon réel : terrain lointain très précis, photo du sol la plus nette (4096), forêts et bâtiments très denses, herbe lointaine et objets détaillés. Réservé aux ordinateurs les plus puissants : les nouveaux lieux prennent plus de temps à générer et la fréquence d’images diminue." },
]

export const devPresets = [
  { id: "off", label: "Désactivé" },
  { id: "lod", label: "LOD" },
  { id: "loading", label: "Chargement" },
  { id: "physics", label: "Physique" },
  { id: "all", label: "Tout" },
]

export const config = ref({})
export const status = ref({})
export const dev = ref({ on: {}, lastPreset: "lod", active: false })
export const help = ref(null)          // the setting pointed at (the side card's help)
export const cacheConfirm = ref(false) // Clear cache: the confirmation is showing
export const cacheBusy = ref(false)    // Clear cache: sent, waiting for the server's answer
export const cacheResult = ref("")     // "Freed 1.2 GB" / an error
let cacheClearsAt = 0                  // status.cache.clears when the clear was sent
let cacheSentAt = 0
let lastWriteAt = 0 // a poll answered just after a uiSet may carry the value from before it
export const pathText = ref({ cache: "", beammp: "" }) // the typed paths
export const pathBusy = ref("")   // the path ('cache' / 'beammp') whose answer is awaited (its window open, or typed)
export const pathPick = ref(false) // ... from the system's window
export const pathMsg = ref({})    // path -> the server's last answer { ok, text }
let pathAnswers = 0               // status.paths.answers when it was sent
let pathSentAt = 0
export const optionConfig = { value: o => o.value, label: o => o.label }    // (BngSelect: our options' fields)
export const presetLine = computed(() => {
  const p = qualityPresets.find(q => q.id === config.value.quality)
  return p ? `${p.name}: ${p.desc}` : ""
})
export const visibleItems = category => category.items.filter(it => !it.showIf || it.showIf(config.value))
export const categoryNamed = name => settingsSchema.find(c => c.name === name) || settingsSchema[0]

// Extract global defaults (persisted settings only)
export const defaultSettings = {}
settingsSchema.forEach(cat => {
  cat.items.forEach(item => { if (item.default !== undefined && !item.virtual) defaultSettings[item.id] = item.default })
})

export const connectionText = computed(() => {
  const s = status.value
  if (!s.connection) return "Mod non chargé"
  const names = { connected: "Connecté", connecting: "Connexion en cours", disconnected: "Déconnecté" }
  let t = names[s.connection] || s.connection
  if (s.session) t += ` (session ${s.session})`
  if (s.lastError) t += ` - ${s.lastError}`
  return t
})

export const statusText = computed(() => status.value.status || "-")

// the connection banner's state line (core.banner(): starting / not running / lost / offline / degraded
// / connected, plus the edge guard's line) and its level (info / ok / warn / error)
export const bannerText = computed(() => (status.value.banner && status.value.banner.text) || "")
export const bannerLevel = computed(() => (status.value.banner && status.value.banner.level) || "info")
// a newer version on GitHub: { current, latest, url } (core.updateInfo)
export const update = computed(() => status.value.update || null)
export function openUpdate() {
  const url = update.value && update.value.url
  if (url) engineLua(`openWebBrowser(${JSON.stringify(url)})`)
}

export function fmt(v, digits) {
  return (typeof v === "number") ? v.toFixed(digits) : "-"
}

export function infoValue(item) {
  const s = status.value
  if (item.id === "connection") return connectionText.value
  if (item.id === "anchor") return s.anchorId ? `#${s.anchorId}  ${fmt(s.anchorLat, 5)}, ${fmt(s.anchorLon, 5)}` : "Aucune"
  if (item.id === "player") return (typeof s.playerLat === "number") ? `${fmt(s.playerLat, 5)}, ${fmt(s.playerLon, 5)}  (${fmt(s.dist / 1000, 1)} km de l’origine)` : "-"
  if (item.id === "attribution") return s.attribution || "-"
  if (item.id === "credits") return s.credits || "-"
  if (item.id === "reportPost") return "Enregistré localement ; aucun dépôt GitHub n’est configuré"
  if (item.id === "weather") return s.weather || "-"
  if (item.id === "gravity") return s.gravity || "-"
  if (item.id === "deshadow") return s.deshadow || "désactivé"
  if (item.id === "colormatch") return s.colormatch || "désactivé"
  if (item.id === "cacheUsage") return (s.cache && s.cache.line) || "-"
  return ""
}

function luaValue(val) {
  if (typeof val === "boolean") return val ? "true" : "false"
  if (typeof val === "number") return String(val)
  return JSON.stringify(String(val))
}

export function showWelcome() {
  engineLua("if guadeloupeEarth_settings and guadeloupeEarth_settings.showWelcome then guadeloupeEarth_settings.showWelcome() end")
}

// Feedback buttons: settings.lua closes the menu, then opens the report window or starts the profiler
export function openFeedback(what) {
  engineLua(`if guadeloupeEarth_settings and guadeloupeEarth_settings.feedback then guadeloupeEarth_settings.feedback(${JSON.stringify(what)}) end`)
}

export function engineLua(script, cb) {
  if (!window.bngApi || !window.bngApi.engineLua) return
  window.bngApi.engineLua(script, cb)
}

// The poll refreshes the values too: weather.lua / sky.lua switch Weather and Sky to Manual by
// themselves when they are changed in the game, and the dropdowns show it within 2 s.
export function applyState(state) {
  if (!state) return
  if (state.settings && Date.now() - lastWriteAt > 1000) config.value = { ...defaultSettings, ...state.settings }
  if (state.status) status.value = state.status
  const c = status.value.cache
  if (cacheBusy.value && c && c.clears > cacheClearsAt) { // the server's answer to our clear
    cacheBusy.value = false
    cacheResult.value = `${c.clearedText || "0 Mo"} libérés`
  } else if (cacheBusy.value && Date.now() - cacheSentAt > 120000) { // a server without the cache, or gone
    cacheBusy.value = false
    cacheResult.value = "Aucune réponse du serveur"
  }
  const p = status.value.paths
  if (pathBusy.value && p && p.answers > pathAnswers && p.result) { // the server's answer to our choice
    pathMsg.value = { ...pathMsg.value, [p.result.what]: p.result }
    if (p.result.ok) pathText.value = { ...pathText.value, [p.result.what]: "" }
    pathBusy.value = ""
  } else if (pathBusy.value && Date.now() - pathSentAt > (pathPick.value ? 960000 : 30000)) {
    pathMsg.value = { ...pathMsg.value, [pathBusy.value]: { ok: false, text: "Aucune réponse du serveur" } }
    pathBusy.value = ""
  }
  if (state.dev) dev.value = state.dev
}

// The cache folder and the BeamMP launcher: what they are now (the server's app_paths) or the last answer
export function pathNote(item) {
  const m = pathMsg.value[item.what]
  if (m) return m.text
  if (pathBusy.value === item.what) return pathPick.value ? "Sélectionnez le dossier dans la fenêtre ouverte (Alt+Tab si elle est derrière le jeu)" : "…"
  const p = status.value.paths
  if (!p) return "-"
  if (item.what === "cache") {
    return p.cacheNext && p.cacheNext !== p.cacheDir ? `Utilisé : ${p.cacheDir} (au prochain lancement : ${p.cacheNext})` : `Utilisé : ${p.cacheDir || "-"}`
  }
  return p.beammp ? `Actuel : ${p.beammp}` : "Aucun lanceur détecté"
}

export function sendPath(item, pick, text) {
  pathMsg.value = { ...pathMsg.value, [item.what]: null }
  pathAnswers = (status.value.paths && status.value.paths.answers) || 0
  const script = `guadeloupeEarth_settings and guadeloupeEarth_settings.uiPathSet(${JSON.stringify(item.what)}, ${pick ? "true" : "false"}, ${JSON.stringify(text || "")}) or nil`
  engineLua(script, res => {
    if (res && res.ok) { pathBusy.value = item.what; pathPick.value = pick; pathSentAt = Date.now() }
    else pathMsg.value = { ...pathMsg.value, [item.what]: { ok: false, text: (res && res.error) || "Mod non chargé" } }
  })
}

export function usePath(item) {
  const t = (pathText.value[item.what] || "").trim()
  if (t && !pathBusy.value) sendPath(item, false, t)
}

// typing in a text box: the game's keys off meanwhile
export function typing(on) { engineLua(`if setCEFTyping then setCEFTyping(${on ? "true" : "false"}) end`) }

export function refresh() {
  engineLua("guadeloupeEarth_settings and guadeloupeEarth_settings.uiState() or nil", applyState)
}

export function updateSetting(key) {
  const script = `guadeloupeEarth_settings and guadeloupeEarth_settings.uiSet(${JSON.stringify(key)}, ${luaValue(config.value[key])}) or nil`
  lastWriteAt = Date.now()
  engineLua(script, res => {
    if (res && res.value !== undefined) config.value[key] = res.value // the Lua side clamps
    if (res && res.quality) config.value.quality = res.quality         // (a graphics knob moved: Custom, or a preset)
  })
}

export function resetSetting(item) {
  config.value[item.id] = item.default
  updateSetting(item.id)
}

// A typed number (type "number"): applied on Enter or when the box loses focus; anything else puts the value back.
export function onNumberEnter(item, text) {
  const n = Number(String(text).trim())
  if (String(text).trim() === "" || !Number.isFinite(n)) return false
  config.value[item.id] = Math.max(item.min ?? -Infinity, Math.min(item.max ?? Infinity, n))
  updateSetting(item.id)
  return true
}

export function onSliderChange(item, val) {
  config.value[item.id] = val
  updateSetting(item.id)
}

export function onSwitchChange(item, val) {
  config.value[item.id] = val
  updateSetting(item.id)
}

export function onDevChange(item, val) {
  dev.value.on[item.id] = val
  engineLua(`guadeloupeEarth_settings and guadeloupeEarth_settings.uiDevSet(${JSON.stringify(item.id)}, ${luaValue(val)}) or nil`, state => {
    if (state) dev.value = state
  })
}

export function applyDevPreset(name) {
  engineLua(`guadeloupeEarth_settings and guadeloupeEarth_settings.uiDevPreset(${JSON.stringify(name)}) or nil`, state => {
    if (state) dev.value = state
  })
}

// Clear cache: the button asks first (cacheConfirm), Clear sends it; the poll sees the answer
export function askClearCache() {
  cacheResult.value = ""
  cacheConfirm.value = true
}

export function confirmClearCache() {
  cacheConfirm.value = false
  cacheClearsAt = (status.value.cache && status.value.cache.clears) || 0
  engineLua("guadeloupeEarth_settings and guadeloupeEarth_settings.uiCacheClear() or nil", res => {
    if (res && res.ok) { cacheBusy.value = true; cacheSentAt = Date.now() }
    else cacheResult.value = (res && res.error) || "Mod non chargé"
  })
}

export function selectOption(item, val) {
  if (item.id === "grass") { setGrass(val); return }
  config.value[item.id] = val
  updateSetting(item.id)
}

// A select's value: the Grass control is two settings (groundCover on / off and groundCoverDensity)
export function valueOf(item) {
  if (item.id === "grass") return config.value.groundCover === false ? "off" : (config.value.groundCoverDensity || "normal")
  return config.value[item.id]
}

export function setGrass(val) {
  if (val === "off") {
    config.value.groundCover = false
    updateSetting("groundCover")
  } else {
    config.value.groundCover = true
    config.value.groundCoverDensity = val
    updateSetting("groundCoverDensity")
    updateSetting("groundCover")
  }
}

// A preset card: settings.lua setQuality sets its knobs and answers with every value
export function setQuality(id) {
  lastWriteAt = Date.now()
  config.value.quality = id
  engineLua(`guadeloupeEarth_settings and guadeloupeEarth_settings.uiSet("quality", ${JSON.stringify(id)}) or nil`, res => {
    if (res && res.settings) config.value = { ...defaultSettings, ...res.settings }
  })
}

export function presetName(id) {
  const p = qualityPresets.find(q => q.id === id)
  return p ? p.name : id
}

// the preset the first run's detection picked ("Steam Deck: medium")
export const detectedPick = computed(() => {
  const d = config.value.qualityDetected || ""
  const k = d.lastIndexOf(": ")
  return k >= 0 ? d.slice(k + 2) : ""
})

// Back: to the menu the page was opened from (the pause menu in a level, else the main menu)
export function close() {
  engineLua("if guadeloupeEarth_settings and guadeloupeEarth_settings.closeSettings then guadeloupeEarth_settings.closeSettings() end")
}

// The poll, while any settings page is open (started / stopped by each: a count)
let users = 0
let pollTimer = null
export function startPolling() {
  if (users++ === 0) {
    if (!Object.keys(config.value).length) config.value = { ...defaultSettings }
    refresh()
    pollTimer = setInterval(refresh, 2000) // status lines while a page is open
  }
}
export function stopPolling() {
  if (--users <= 0) {
    users = 0
    if (pollTimer) clearInterval(pollTimer)
    pollTimer = null
  }
}
