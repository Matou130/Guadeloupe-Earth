// Shared geographic policy for the Guadeloupe Earth map UI.
// The rectangle is a working tile envelope, not an official island polygon.
export const MOD_NAME = "Guadeloupe Earth"

export const REGION = Object.freeze({
  south: 15.75,
  west: -61.95,
  north: 16.60,
  east: -60.90
})

// Extra map-only margin for the nearby islands and open sea around the driveable world.
export const MAP_TILE_BOUNDS = Object.freeze({
  south: 15.25,
  west: -63.20,
  north: 17.10,
  east: -60.00
})

export const CENTRE = Object.freeze({ lat: 16.175, lon: -61.425 })
export const DEFAULT_POSITION = Object.freeze({ lat: 16.2415, lon: -61.5330 })
export const DEFAULT_ZOOM = 10
// Keep the map centred on Guadeloupe and stop at the EOX layers' native z14 resolution,
// so deeper zooms do not stretch the same pixels and blur the roads.
export const MIN_ZOOM = 10
export const MAX_ZOOM = 14

export const SPAWN_POINTS = Object.freeze([
  { id: "pointe_a_pitre", name: "Pointe-à-Pitre", lat: 16.2415, lon: -61.5330 },
  { id: "basse_terre", name: "Basse-Terre", lat: 15.9970, lon: -61.7290 },
  { id: "capesterre", name: "Capesterre-Belle-Eau", lat: 16.0450, lon: -61.5650 },
  { id: "airport", name: "Aéroport Pôle Caraïbes", lat: 16.2650, lon: -61.5310 },
  { id: "saint_francois", name: "Saint-François", lat: 16.2520, lon: -61.2730 },
  { id: "deshaies", name: "Deshaies", lat: 16.3060, lon: -61.7950 },
  { id: "grand_bourg", name: "Grand-Bourg – Marie-Galante", lat: 15.8830, lon: -61.3150 },
  { id: "terre_de_haut", name: "Terre-de-Haut – Les Saintes", lat: 15.8670, lon: -61.5830 },
  { id: "la_desirade", name: "La Désirade", lat: 16.3080, lon: -61.0800 }
])

export function isInsideRegion(lat, lon) {
  return Number.isFinite(Number(lat)) && Number.isFinite(Number(lon))
    && Number(lat) >= REGION.south && Number(lat) <= REGION.north
    && Number(lon) >= REGION.west && Number(lon) <= REGION.east
}

export function clampToRegion(lat, lon) {
  return {
    lat: Math.max(REGION.south, Math.min(REGION.north, Number(lat))),
    lon: Math.max(REGION.west, Math.min(REGION.east, Number(lon)))
  }
}

export function clampMapView(view) {
  const centre = clampToRegion(view.lat, view.lon)
  return {
    ...view,
    ...centre,
    z: Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, Number(view.z) || DEFAULT_ZOOM))
  }
}

function tileIntersectsBounds(z, x, y, bounds) {
  z = Number(z); x = Number(x); y = Number(y)
  if (!Number.isInteger(z) || !Number.isInteger(x) || !Number.isInteger(y) || z < 0 || z > 30) return false
  const n = 2 ** z
  if (x < 0 || x >= n || y < 0 || y >= n) return false
  const lat = ty => Math.atan(Math.sinh(Math.PI * (1 - 2 * ty / n))) * 180 / Math.PI
  const west = x / n * 360 - 180
  const east = (x + 1) / n * 360 - 180
  const north = lat(y)
  const south = lat(y + 1)
  return !(north < bounds.south || south > bounds.north || east < bounds.west || west > bounds.east)
}

export function tileIntersectsRegion(z, x, y) { return tileIntersectsBounds(z, x, y, REGION) }
export function tileIntersectsMapRegion(z, x, y) { return tileIntersectsBounds(z, x, y, MAP_TILE_BOUNDS) }

export function getSpawn(id) {
  return SPAWN_POINTS.find(point => point.id === id) || null
}
