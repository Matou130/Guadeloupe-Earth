<template>
  <!-- A one-time welcome (the user, 2026-10-15: "add a 1 time popup with info about this project"): what it is,
       the companion server, the keys, credits. Shown once per WELCOME_VERSION by settings.lua; again from the
       settings page's "Show welcome". -->
  <div class="earth-welcome" @keydown.esc.stop="done" tabindex="-1" ref="rootEl">
    <div class="card">
      <div class="head">
        <svg class="archipelago" viewBox="0 0 64 64" aria-hidden="true">
          <defs>
            <linearGradient id="islandSea" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stop-color="#1d6596"/>
              <stop offset="1" stop-color="#102f4a"/>
            </linearGradient>
          </defs>
          <rect x="2" y="2" width="60" height="60" rx="18" fill="url(#islandSea)" stroke="#8bc9ed" stroke-width="1.5"/>
          <path d="M17 12l7 2 3 5-2 6 4 5-2 7-6 4-3-5-5-3 2-7-3-5z" fill="#72bd83" stroke="#d3efc9" stroke-width="1.2" stroke-linejoin="round"/>
          <path d="M37 15l6 1 4 5-2 6-5 3-4-4 1-6z" fill="#91cc8c" stroke="#d3efc9" stroke-width="1.2" stroke-linejoin="round"/>
          <path d="M31 43l4 1 1 3-3 2-3-2zM48 38l3 1 1 3-3 2-2-3zM13 48l3 1-1 3-3-1z" fill="#b7df98"/>
          <circle cx="32" cy="32" r="2.2" fill="#fff2b0"/>
        </svg>
        <div>
          <div class="title">Bienvenue dans Guadeloupe Earth</div>
          <div class="sub">Parcourez la Guadeloupe au volant.</div>
        </div>
      </div>

      <div class="server" :class="{ ok: connected, bad: connected === false }">
        <span class="dot"></span>
        <span v-if="connected">Guadeloupe Earth est connecté : le monde insulaire se génère autour de vous.</span>
        <span v-else-if="connected === false">Le serveur Guadeloupe Earth n’est pas lancé. Démarrez-le avec <b>run_server</b> (Windows)
          ou <b>run_server.sh</b> (Linux) dans le dossier Guadeloupe Earth, puis revenez ici.</span>
        <span v-else>Recherche du serveur Guadeloupe Earth…</span>
      </div>

      <div class="cols">
        <div class="col">
          <div class="h">Fonctionnement</div>
          <p>Un programme compagnon sur votre ordinateur génère la Guadeloupe au fil de votre trajet : relief, routes, bâtiments,
            végétation, eau et images aériennes à partir de données cartographiques ouvertes. Laissez-le fonctionner pendant la partie.</p>
          <p>Un lieu visité pour la première fois peut mettre quelques secondes à apparaître. Il pourra ensuite être chargé depuis le cache local.</p>
          <div class="h">Se déplacer</div>
          <ul>
            <li><b>M</b> : ouvre la carte de la Guadeloupe. Recherchez un lieu, faites un clic droit pour vous y téléporter ou un clic gauche pour définir un itinéraire GPS.</li>
            <li><b>Conduite automatique</b> dans la barre GPS : le véhicule suit l’itinéraire.</li>
            <li><b>Lieux</b> sur la carte : enregistrez des endroits et retrouvez-les plus tard.</li>
          </ul>
        </div>
        <div class="col">
          <div class="h">Aidez à l’améliorer</div>
          <ul>
            <li><b>Ctrl+Maj+E</b> : signalez un problème (une capture d’écran, le lieu et la fréquence d’images sont enregistrés
              dans un rapport prêt à publier).</li>
            <li><b>Ctrl+Maj+Y</b> : enregistrez une analyse des performances de 30 secondes.</li>
          </ul>
          <div class="h">Réglages</div>
          <p>Menu Pause → Mods → <b>Guadeloupe Earth</b> : distance de vue, météo, ciel, herbe, cache et connexion Internet. Choisissez Automatique, En ligne ou Hors ligne selon votre connexion et les données déjà téléchargées.</p>
          <div class="h">Données</div>
          <p class="small">Images, relief et cartes proviennent de sources ouvertes : USGS, USDA NAIP, organismes cartographiques régionaux et nationaux,
            EOX Sentinel-2 cloudless, contributeurs d’Overture Maps et d’OpenStreetMap, Mapterhorn.
            Les sources utilisées sont créditées à l’écran pendant la conduite.</p>
          <p class="small preview">Version bêta : quelques imperfections sont possibles. Merci de l’essayer !</p>
        </div>
      </div>

      <div class="btns">
        <button class="btn" @click="openMap">Ouvrir la carte</button>
        <button class="btn primary" @click="done">Commencer à conduire</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, nextTick } from "vue"

const rootEl = ref(null)
const connected = ref(null)
let timer = null

function engineLua(script, cb) {
  if (window.bngApi && window.bngApi.engineLua) window.bngApi.engineLua(script, cb)
}
function poll() {
  engineLua("guadeloupeEarth_settings and guadeloupeEarth_settings.uiMapState and guadeloupeEarth_settings.uiMapState() or nil", s => {
    connected.value = s ? !!s.connected : false
  })
}
// marks the welcome seen and goes back to driving (or to the map)
function finish(state) {
  engineLua(`if guadeloupeEarth_settings and guadeloupeEarth_settings.uiWelcomeDone then guadeloupeEarth_settings.uiWelcomeDone() end; ` +
            `if guadeloupeEarth_settings and guadeloupeEarth_settings.navigate then guadeloupeEarth_settings.navigate('${state}') ` +
            `else guihooks.trigger('ChangeState', {state = '${state}'}) end`)
}
function done() { finish("play") }
function openMap() { finish("guadeloupeEarthMap") }

onMounted(() => {
  poll()
  timer = setInterval(poll, 1000)
  nextTick(() => rootEl.value && rootEl.value.focus())
})
onUnmounted(() => clearInterval(timer))
</script>

<style scoped>
.earth-welcome {
  position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
  background: rgba(8, 10, 14, 0.62); outline: none; font-family: inherit; color: #e8edf2;
}
.card {
  width: min(980px, 92vw); max-height: 88vh; overflow-y: auto; padding: 26px 30px 22px;
  background: rgba(18, 22, 28, 0.96); border: 1px solid rgba(255, 255, 255, 0.14); border-radius: 10px;
  box-shadow: 0 18px 60px rgba(0, 0, 0, 0.55);
}
.head { display: flex; gap: 16px; align-items: center; margin-bottom: 16px; }
.archipelago { width: 64px; height: 64px; flex: none; }
.title { font-size: 28px; font-weight: 700; letter-spacing: 0.01em; }
.sub { font-size: 15px; color: #9fb0c0; margin-top: 2px; }
.server {
  display: flex; gap: 10px; align-items: center; padding: 9px 12px; margin-bottom: 18px; font-size: 14px;
  border-radius: 6px; background: rgba(255, 255, 255, 0.05);
}
.server .dot { width: 10px; height: 10px; border-radius: 50%; background: #8a949e; flex: none; }
.server.ok .dot { background: #4cc46a; }
.server.bad { background: rgba(224, 118, 28, 0.14); }
.server.bad .dot { background: #e0761c; }
.cols { display: flex; gap: 28px; }
.col { flex: 1; min-width: 0; }
.h { margin: 14px 0 6px; font-size: 12px; text-transform: uppercase; letter-spacing: 0.06em; color: #9fb0c0; }
.h:first-child { margin-top: 0; }
p { margin: 0 0 8px; font-size: 14px; line-height: 1.45; }
ul { margin: 0 0 8px; padding-left: 18px; font-size: 14px; line-height: 1.45; }
li { margin-bottom: 4px; }
.small { font-size: 12px; color: #aab6c2; }
.preview { color: #ffc28a; }
.btns { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; }
.btn {
  padding: 9px 18px; font-size: 14px; color: #fff; background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.22); border-radius: 5px; cursor: pointer;
}
.btn:hover { background: rgba(255, 255, 255, 0.16); }
.btn.primary { background: #e0761c; border-color: #e0761c; }
.btn.primary:hover { background: #f08a32; }
@media (max-width: 760px) { .cols { flex-direction: column; gap: 4px; } }
</style>
