import { lua } from "@/bridge"

// Guadeloupe Earth: a tab of its own in the Pause Menu (the user, 2026-10-28: "its own tab in the pause menu like where
// BeamMP puts it ... and have each page listed in the menu on the side"): ui_pause_actions.registerModTab, then one
// side button per settings page (EarthSettingsPage.vue with that page; EarthSettingsSide.vue as the tab's second card).
// The same pages as a full page of their own (EarthSettings.vue, a route: the main menu). Lua side:
// lua/ge/extensions/guadeloupeEarth/settings.lua.
//
// The world map (EarthMap.vue): a full-screen route of its own ("guadeloupeEarthMap", opened by the
// map key (M, the pause menu Map, or a bound key) through guadeloupeEarth_settings.toggleMap). No pause-menu button of its own
// (the user, 2026-10-16: "move the map out of the mods tab"; the stock Map entry opens it). The route follows ui/ui-vue/mods/README.md "Standalone routes"; any failure
// there is logged and leaves the settings tab alone.
const TAB_ID = "guadeloupeEarth"
const MOD_ROOT = "/ui/ui-vue/mods/guadeloupeEarth"
const MAP_SOURCE = "guadeloupeEarth.routes"
function mapRoutes(EarthMap, EarthWelcome, EarthSettings) {
  return [
  {
    // the full settings page (the user, 2026-10-28: "a whole separate page like how BeamMP's settings page is"):
    // the main menu's way in (guadeloupeEarth_settings.openSettings); in a level the pause menu's tab has the same pages
    path: "/guadeloupe-earth-settings",
    name: "guadeloupeEarthSettings",
    component: EarthSettings,
    meta: {
      luaRoute: {
        title: "Réglages Guadeloupe Earth",
        backTarget: "menu",
      },
    },
  },
  {
    // the one-time welcome (settings.lua shows it once per WELCOME_VERSION in our level)
    path: "/guadeloupe-earth-welcome",
    name: "guadeloupeEarthWelcome",
    component: EarthWelcome,
    meta: {
      luaRoute: {
        title: "Bienvenue dans Guadeloupe Earth",
        backTarget: "play",
      },
    },
  },
  {
    path: "/guadeloupe-earth-map",
    name: "guadeloupeEarthMap",
    component: EarthMap,
    meta: {
      luaRoute: {
        title: "Carte Guadeloupe Earth",
        backTarget: "play",
      },
    },
  },
  ]
}

function toLuaRoutes(records) {
  return records.map(record => ({ name: record.name, path: record.path, meta: record.meta }))
}

// The pause menu's Guadeloupe Earth tab: the tab first (its buttons need it), then a side button per settings page
async function registerPauseTab() {
  try {
    const store = await import("./earthSettingsStore.js")
    await lua.extensions.ui_pause_actions.registerModTab({
      id: TAB_ID,
      label: "Guadeloupe Earth",
      icon: "globe",
      card2ComponentName: `${MOD_ROOT}/EarthSettingsSide.vue`,
    })
    for (const [i, page] of store.settingsSchema.entries()) {
      await lua.extensions.ui_pause_actions.registerModButton({
        id: store.pageId(page.name, i),
        tabId: TAB_ID,
        label: page.name,
        icon: store.PAGE_ICONS[page.name] || "cogOutline",
        componentName: `${MOD_ROOT}/EarthSettingsPage.vue`,
        props: { page: page.name },
      })
    }
  } catch (e) {
    console.error("Guadeloupe Earth: pause menu tab failed", e)
  }
}

async function registerMapRoute() {
  try {
    if (!window.bngRoutes || !lua.extensions.ui_router_routeManager) return
    // imported here, not at the top: a map that fails to compile must not cost the settings button
    const routes = mapRoutes((await import("./EarthMap.vue")).default, (await import("./EarthWelcome.vue")).default,
                             (await import("./EarthSettings.vue")).default)
    window.bngRoutes.add([{ path: MAP_SOURCE, routes }])
    const result = await lua.extensions.ui_router_routeManager.registerModRoutes(MAP_SOURCE, toLuaRoutes(routes))
    if (!result?.success) {
      window.bngRoutes.remove([MAP_SOURCE])
      console.error("Guadeloupe Earth: map route not registered", result?.errors)
    }
  } catch (e) {
    console.error("Guadeloupe Earth: map route failed", e)
  }
}

export async function onLoad() {
  // the old shared-Mods-tab button, if this UI session still has one (before the tab: its id is the first page's)
  try { await lua.extensions.ui_pause_actions.unregisterModButton("guadeloupeEarth-settings") } catch (e) { /* none */ }
  await registerPauseTab()
  // tell the mod the page exists: its imgui window becomes a compact HUD (settings.lua)
  if (window.bngApi && window.bngApi.engineLua) {
    window.bngApi.engineLua("if guadeloupeEarth_settings then guadeloupeEarth_settings.setPageExists(true) end")
  }
  // an older version's map button, if this UI session still has one
  try { await lua.extensions.ui_pause_actions.unregisterModButton("guadeloupeEarth-map") } catch (e) { /* none */ }
  await registerMapRoute()
}

export async function onUnload() {
  await lua.extensions.ui_pause_actions.unregisterModTab(TAB_ID)       // (its buttons with it)
  try {
    if (window.bngRoutes) window.bngRoutes.remove([MAP_SOURCE])
    if (lua.extensions.ui_router_routeManager) {
      await lua.extensions.ui_router_routeManager.unregisterModRoutes(MAP_SOURCE, { fallbackRoute: "play" })
    }
  } catch (e) {
    console.error("Guadeloupe Earth: map unload failed", e)
  }
  if (window.bngApi && window.bngApi.engineLua) {
    window.bngApi.engineLua("if guadeloupeEarth_settings then guadeloupeEarth_settings.setPageExists(false) end")
  }
}
