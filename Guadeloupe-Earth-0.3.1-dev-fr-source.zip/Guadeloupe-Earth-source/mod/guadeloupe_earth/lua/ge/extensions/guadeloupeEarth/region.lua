-- Geographic policy for the Guadeloupe Earth fork.
-- Bounds are a working envelope, not an official island-boundary polygon.
local M = {}

M.NAME = 'Guadeloupe Earth'
M.VERSION = '0.2.2-dev'
M.BOUNDS = {
  south = 15.75,
  west = -61.95,
  north = 16.60,
  east = -60.90
}
M.CENTRE = { lat = 16.175, lon = -61.425 }
M.DEFAULT = { lat = 16.2415, lon = -61.5330 }

function M.contains(lat, lon)
  lat, lon = tonumber(lat), tonumber(lon)
  if not lat or not lon or lat ~= lat or lon ~= lon then return false end
  if lat == math.huge or lat == -math.huge or lon == math.huge or lon == -math.huge then return false end
  return lat >= M.BOUNDS.south and lat <= M.BOUNDS.north
     and lon >= M.BOUNDS.west and lon <= M.BOUNDS.east
end

function M.validate(lat, lon)
  if not M.contains(lat, lon) then
    return false, 'Position outside Guadeloupe Earth coverage'
  end
  return true
end

return M
