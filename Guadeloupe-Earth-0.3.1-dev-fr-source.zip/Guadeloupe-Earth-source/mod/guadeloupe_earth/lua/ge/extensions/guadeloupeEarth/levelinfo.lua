-- The level's info.json for the freeroam level select (the user, 2026-10-20: "have the location selector
-- automatically match the places list"): a spawn point per saved Guadeloupe place (places.lua) and the
-- default start, with level details scoped to the Guadeloupe archipelago.
--
-- Written to /levels/guadeloupe_earth/info.json in the user folder, where it stands over the mod's own copy (checked in
-- game 2026-10-20: the level list reads the user folder's; deleting it brings the mod's back). core_levels drops its
-- level list when a file under /levels/ changes, so the menu shows the new list by itself. Written only when its text
-- changes (each write is a file event and a rebuilt level list).
--
-- The spawn point the player picks is saved by the game (setSpawnpoint.setDefaultSP, settings/cloud/game-state.json
-- levels.guadeloupe_earth.defaultSpawnPointName); our level has no SpawnSphere of those names, the car starts at the
-- default one, and core's start teleport goes to the place it names (M.chosen).

local M = {}

M.PATH = '/levels/guadeloupe_earth/info.json'
M.GAME_STATE = 'settings/cloud/game-state.json'
M.LEVEL = 'guadeloupe_earth'
M.DEFAULT = 'spawn_default'
-- No random-world spawn in the Guadeloupe-only fork.
M.PREFIX = 'gue_place_'
M.PLACE_PREVIEWS = 'places/'           -- per place: <PLACE_PREVIEWS><previewKey>.jpg (the server writes them)

-- Guadeloupe Earth level metadata. The size is the approximate geographic envelope in metres,
-- not the rendered terrain-block dimensions (the rectangular envelope includes near-shore water).
M.BASE = {
  title = 'Guadeloupe Earth',
  description = 'Explore Grande-Terre, Basse-Terre and the nearby Guadeloupe dependencies in BeamNG.drive. '
    .. 'The Guadeloupe Earth companion server streams the regional terrain, imagery and roads.',
  previews = {},
  size = { 96500, 83400 },
  biome = 'Caribbean tropical climate, rainforest, volcanic relief and coastal vegetation',
  roads = 'Guadeloupe road network: urban streets, coastal routes, rural roads and mountain roads',
  suitablefor = 'Freeroam, road trips, exploring and off-roading',
  features = 'Regional terrain, satellite imagery, roads, bridges, buildings, vegetation and coastlines',
  country = 'Guadeloupe, France',
  authors = 'Guadeloupe Earth',
  defaultSpawnPointName = M.DEFAULT,
  supportsTraffic = true,
  supportsTimeOfDay = true,
}

-- A place's preview file name: its rounded position (a rename keeps the picture; a moved place gets a new one).
function M.previewKey(lat, lon) return string.format('%.4f_%.4f', lat, lon):gsub('-', 'm'):gsub('%.', 'p') end

local function copy(t)
  local o = {}
  for k, v in pairs(t) do o[k] = type(v) == 'table' and copy(v) or v end
  return o
end

-- The info table for places ({ id, name, lat, lon }); hasPreview(key) -> true when that place's picture exists.
function M.build(placeList, hasPreview)
  local info = copy(M.BASE)
  local sp = {
    { objectname = M.DEFAULT, translationId = 'Last position / Pointe-à-Pitre',
      description = 'Return to your last Guadeloupe position, or start in Pointe-à-Pitre.' },
  }
  for _, p in ipairs(placeList or {}) do
    local key = M.previewKey(p.lat, p.lon)
    local item = { objectname = M.PREFIX .. tostring(p.id), translationId = p.name,
      description = string.format('%.5f, %.5f', p.lat, p.lon) }
    if hasPreview and hasPreview(key) then item.preview = M.PLACE_PREVIEWS .. key .. '.jpg' end
    sp[#sp + 1] = item
  end
  info.spawnPoints = sp
  return info
end

local last = nil -- the text written last (or read back)

-- Write the info for placeList when it differs from the file. Returns true when it wrote.
function M.write(placeList)
  local enc, write, read = rawget(_G, 'jsonEncodePretty') or rawget(_G, 'jsonEncode'), rawget(_G, 'writeFile'),
    rawget(_G, 'readFile')
  if not enc or not write then return false end
  local function hasPreview(key)
    return FS and FS.fileExists and FS:fileExists('/levels/guadeloupe_earth/' .. M.PLACE_PREVIEWS .. key .. '.jpg') or false
  end
  local ok, text = pcall(enc, M.build(placeList, hasPreview))
  if not ok or type(text) ~= 'string' then return false end
  if last == nil and read then
    local ok2, cur = pcall(read, M.PATH)
    last = ok2 and cur or ''
  end
  if text == last then return false end
  local ok3, res = pcall(write, M.PATH, text)
  if not ok3 or res == false then
    log('W', 'guadeloupeEarth', 'level info: write failed: ' .. tostring(res))
    return false
  end
  last = text
  return true
end

-- The places whose picture is not there yet and not asked for this session: { { key, lat, lon } }, each marked asked.
local asked = {}
function M.missing(placeList)
  local out = {}
  for _, p in ipairs(placeList or {}) do
    local key = M.previewKey(p.lat, p.lon)
    if not asked[key] and not (FS and FS.fileExists
        and FS:fileExists('/levels/guadeloupe_earth/' .. M.PLACE_PREVIEWS .. key .. '.jpg')) then
      asked[key] = true
      out[#out + 1] = { key = key, lat = p.lat, lon = p.lon }
    end
  end
  return out
end

-- The spawn point the player picked for our level: M.DEFAULT, M.PREFIX .. id, or nil.
function M.chosen()
  local read = rawget(_G, 'jsonReadFile')
  if not read then return nil end
  local ok, data = pcall(read, M.GAME_STATE)
  local lv = ok and type(data) == 'table' and type(data.levels) == 'table' and data.levels[M.LEVEL] or nil
  local name = type(lv) == 'table' and lv.defaultSpawnPointName or nil
  return type(name) == 'string' and name or nil
end

-- The place id of a spawn point name, or nil.
function M.placeId(name)
  local id = type(name) == 'string' and name:match('^' .. M.PREFIX .. '(%d+)$')
  return id and tonumber(id) or nil
end

function M._reset() last, asked = nil, {} end -- tests

return M
