# Guadeloupe Earth and BeamMP

BeamMP support is optional. This preview retains the multiplayer position-sharing plugin under `beammp/Server/GuadeloupeEarth/`, but the old public Guadeloupe Earth server directory integration has been disabled. The plugin is configured as unlisted; players must connect by the normal BeamMP direct-connect/server setup.

Every participating player must have a compatible Guadeloupe Earth companion server running locally, because terrain and map data are built on each player's computer. The map restriction applies to player positions accepted by this fork.

This integration has not yet been tested in a live BeamMP session. Do not expose a public server until authentication, ports, version compatibility and player position filtering have been reviewed.
