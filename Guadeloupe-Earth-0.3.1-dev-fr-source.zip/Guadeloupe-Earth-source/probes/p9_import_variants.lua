local s = require('socket')
local tb = scenetree.findObject('guadeloupeEarthTerrain') or scenetree.findClassObjects('TerrainBlock') and scenetree.findObject(scenetree.findClassObjects('TerrainBlock')[1])
local hm = '/temp/guadeloupeEarth/20261009-224628-3147/hm_11.png'
local LAYER = '/levels/guadeloupe_earth/art/terrains/guadeloupeEarth_layer_2048.png'
local pos = tb:getPosition()
MAXH = tb:getHeightScaleUser()
be:setPhysicsRunning(false)
local out = {name = tb:getName()}
local function run(label, mats, tex)
  local t0 = s.gettime()
  local ok = tb:importMaps(hm, 2.0, MAXH, '', mats, tex, false)
  local t1 = s.gettime()
  tb:setPosition(pos)
  be:reloadCollision()
  out[label] = string.format('import %.0f ms, +reload %.0f ms, ok=%s', (t1-t0)*1000, (s.gettime()-t1)*1000, tostring(ok))
end
run('A_full', {'guadeloupeEarthDirt'}, {{path=LAYER, selected=false, material='guadeloupeEarthDirt', materialId=0, channel='R', channelId=0}})
run('B_matsNoTex', {'guadeloupeEarthDirt'}, {})
run('C_none', {}, {})
run('D_full_again', {'guadeloupeEarthDirt'}, {{path=LAYER, selected=false, material='guadeloupeEarthDirt', materialId=0, channel='R', channelId=0}})
be:setPhysicsRunning(true)
out.maxH = MAXH
return jsonEncode(out)
