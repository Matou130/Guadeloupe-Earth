"""Geographic guard tests for the Guadeloupe Earth preview."""
import math
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import guadeloupe_region as region
import mapcells
import numpy as np
import mapdata
import maptiles
import imagery


class NeverFetchImagery:
    chain = ()

    def tiles(self, *args, **kwargs):
        raise AssertionError("out-of-region map tile must not fetch imagery")

    def raw(self, *args, **kwargs):
        raise AssertionError("out-of-region layer tile must not fetch imagery")


class NeverNetworkFetcher:
    def __init__(self):
        self.calls = 0

    def register_chain(self, *args, **kwargs):
        pass

    def get(self, *args, **kwargs):
        self.calls += 1
        raise AssertionError("out-of-region imagery must never reach the network")

    def miss_alive(self, *args, **kwargs):
        self.calls += 1
        raise AssertionError("out-of-region imagery must not check network miss state")

    def policy(self, *args, **kwargs):
        self.calls += 1
        raise AssertionError("out-of-region imagery must not inspect provider policy")


class GuadeloupeRegionTest(unittest.TestCase):
    def test_spawns_are_inside_working_envelope(self):
        self.assertEqual(len(region.SPAWN_POINTS), 9)
        for place in region.SPAWN_POINTS:
            with self.subTest(place=place["name"]):
                self.assertTrue(region.is_inside(place["lat"], place["lon"]))

    def test_rejects_distant_locations_and_non_finite_values(self):
        for lat, lon in ((39.2834, -76.5934), (48.8566, 2.3522), (float("nan"), -61.4), (16.1, float("inf"))):
            with self.subTest(lat=lat, lon=lon):
                self.assertFalse(region.is_inside(lat, lon))
        with self.assertRaises(ValueError):
            region.require_inside(39.2834, -76.5934)

    def test_tile_intersection_uses_tile_footprint(self):
        def xyz(lat, lon, z):
            x, y = mapcells.tile_xy(lat, lon, z)
            return int(math.floor(float(x))), int(math.floor(float(y)))

        gx, gy = xyz(16.2415, -61.5330, 12)
        ux, uy = xyz(39.2834, -76.5934, 12)
        self.assertTrue(region.tile_intersects(12, gx, gy))
        self.assertFalse(region.tile_intersects(12, ux, uy))

    def test_global_cell_math_is_generic_but_source_gate_is_regional(self):
        # Projection/cell enumeration stays generic for geometry code. The source boundary
        # rejects any cell that does not overlap the Guadeloupe working envelope.
        outside = mapcells.cells_for_bbox(39.0, -77.0, 40.0, -76.0)
        self.assertTrue(outside)
        self.assertFalse(mapcells._cell_intersects_region(outside[0]))
        inside = mapcells.cells_for_bbox(16.20, -61.60, 16.25, -61.50)
        self.assertTrue(inside)
        self.assertTrue(all(mapcells._cell_intersects_region(cell) for cell in inside))

    def test_mapdata_outside_region_never_reads_or_builds(self):
        x, y = mapcells.tile_xy(39.2834, -76.5934, mapcells.ZOOM)
        key = mapcells.CellKey(mapcells.ZOOM, int(math.floor(float(x))), int(math.floor(float(y))))
        instance = object.__new__(mapdata.MapData)
        arrays, hit = instance.layer_arrays(key, "roads")
        self.assertTrue(hit)
        self.assertEqual(str(arrays["provenance"].item()), "null")
        self.assertTrue(len(arrays) > 1)

    def test_map_tile_outside_region_never_fetches(self):
        tiles = maptiles.MapTiles(NeverFetchImagery())
        x, y = mapcells.tile_xy(39.2834, -76.5934, 12)
        self.assertIsNone(tiles.tile(12, int(math.floor(float(x))), int(math.floor(float(y)))))
        self.assertIsNone(tiles.layer_tile("map", 12, int(math.floor(float(x))), int(math.floor(float(y)))))

    def test_satellite_imagery_outside_region_never_checks_cache_or_network(self):
        x, y = mapcells.tile_xy(39.2834, -76.5934, 12)
        x, y = int(math.floor(float(x))), int(math.floor(float(y)))
        fetcher = NeverNetworkFetcher()
        img = imagery.Imagery("/tmp/guadeloupe-earth-test-cache", chain=("eox2016",),
                              fetcher=fetcher, region_only=True)
        try:
            self.assertIsNone(img.raw(img.chain[0], 12, x, y))
            self.assertEqual(img.tiles([(img.chain[0], 12, x, y)]), {(img.chain[0], 12, x, y): None})
            self.assertEqual(fetcher.calls, 0)
        finally:
            img.close()

    def test_export_parent_does_not_cache_children_outside_region(self):
        # A regional-edge export parent contains four children west of the envelope and
        # twelve children intersecting it. Only the latter may be persisted.
        x, y = mapcells.tile_xy(16.2, -61.85, 17)
        x, y = int(math.floor(float(x))), int(math.floor(float(y)))
        parent_x, parent_y = (x >> 2) << 2, (y >> 2) << 2
        fetcher = NeverNetworkFetcher()
        with tempfile.TemporaryDirectory() as cache_dir:
            img = imagery.Imagery(cache_dir, chain=("eox2016",), fetcher=fetcher, region_only=True)
            try:
                img._split_export(imagery.SOURCES["naip"], 17, parent_x + 1, parent_y + 1,
                                  np.full((1024, 1024, 3), 100, dtype=np.uint8))
                saved = []
                for zdir, _, files in os.walk(cache_dir):
                    for name in files:
                        if name.endswith(".jpg"):
                            # cache path: source / z / x / y.jpg
                            parts = Path(zdir).relative_to(cache_dir).parts
                            z, tile_x = int(parts[1]), int(parts[2])
                            tile_y = int(name[:-4])
                            saved.append((z, tile_x, tile_y))
                self.assertGreater(len(saved), 0)
                self.assertTrue(all(region.tile_intersects(*key) for key in saved))
                self.assertEqual(fetcher.calls, 0)
            finally:
                img.close()


if __name__ == "__main__":
    unittest.main()
