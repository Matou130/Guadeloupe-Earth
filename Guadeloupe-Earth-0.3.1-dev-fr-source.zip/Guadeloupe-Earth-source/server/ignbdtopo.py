"""IGN BD TOPO buildings for Guadeloupe, fetched by cell from the public Géoplateforme WFS.

The WFS supplies measured building footprints and, where recorded, heights, floor counts and
materials. It is a regional source for the Guadeloupe Earth fork; other places keep Overture.
MapData writes the decoded features to its normal per-cell cache, so a visited cell works offline.
"""
import json
import logging
import math
import unicodedata
from urllib.parse import urlencode

import numpy as np

import guadeloupe_region
import mapgeom as mg

log = logging.getLogger("earthd.ignbdtopo")

RELEASE = "2026-09"             # bump when the monthly BD TOPO WFS edition advances
URL = "https://data.geopf.fr/wfs"
TYPE_NAME = "BDTOPO_V3:batiment"
PAGE_SIZE = 5000
MAX_FEATURES_PER_CELL = 100000
PROPERTY_NAME = ",".join((
    "geometrie", "cleabs", "nature", "usage_1", "usage_2", "construction_legere",
    "etat_de_l_objet", "nombre_d_etages", "materiaux_des_murs", "materiaux_de_la_toiture", "hauteur",
))


class Error(ValueError):
    """The WFS response was not a complete, usable building layer."""


def applies(cell):
    """Whether a map cell intersects the Guadeloupe working extent."""
    lon0, lat0, lon1, lat1 = cell.bounds()
    return guadeloupe_region.BOUNDS.intersects(lat0, lon0, lat1, lon1)


def _url(bounds, start):
    lon0, lat0, lon1, lat1 = bounds
    params = {
        "service": "WFS", "version": "2.0.0", "request": "GetFeature", "typeNames": TYPE_NAME,
        "count": PAGE_SIZE, "startIndex": start, "outputFormat": "application/json", "srsName": "EPSG:4326",
        "propertyName": PROPERTY_NAME,
        "bbox": f"{lon0:.8f},{lat0:.8f},{lon1:.8f},{lat1:.8f},EPSG:4326",
    }
    return URL + "?" + urlencode(params)


def _fetch(fetcher, bounds, start, kind):
    try:
        response = fetcher.get(_url(bounds, start), kind=kind)
        data = json.loads(response.body)
    except (ValueError, TypeError, KeyError) as e:
        raise Error(f"invalid IGN WFS response at offset {start}: {e}") from e
    if not isinstance(data, dict) or not isinstance(data.get("features"), list):
        raise Error(f"IGN WFS returned no feature list at offset {start}")
    return data


def _number(value):
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return value if math.isfinite(value) and value > 0 else None


def _norm(value):
    value = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode("ascii")
    return " ".join(value.lower().replace("_", " ").replace("-", " ").split())


def _building_class(properties, floors):
    usage = " ".join(_norm(properties.get(k)) for k in ("usage_1", "usage_2"))
    nature = _norm(properties.get("nature"))
    if "residentiel" in usage or "maison" in nature:
        return "apartments" if floors is not None and floors >= 4 else "house"
    if "commercial" in usage or "commerce" in usage or "services" in usage:
        return "commercial"
    if "industriel" in usage or "industrie" in usage or ("industriel" in nature and " ou " not in nature):
        return "industrial"
    if "agricole" in usage or "agriculture" in usage or ("agricole" in nature and " ou " not in nature):
        return "farm_auxiliary"
    if "religieux" in usage or "culte" in usage or "religieux" in nature:
        return "church"
    if "annexe" in usage or "dependance" in usage or "annexe" in nature or "dependance" in nature:
        return "shed"
    return ""


def _wall_material(value):
    value = _norm(value)
    if not value:
        return ""
    if any(x in value for x in ("beton", "ciment", "parpaing")):
        return "concrete"
    if any(x in value for x in ("pierre", "moellon")):
        return "stone"
    if "brique" in value:
        return "brick"
    if "bois" in value:
        return "wood"
    if "metal" in value or "tole" in value:
        return "metal"
    if "enduit" in value or "crepi" in value or "platre" in value:
        return "plaster"
    return ""


def _roof_material(value):
    value = _norm(value)
    if not value:
        return ""
    if any(x in value for x in ("tole", "metal", "zinc", "bac acier")):
        return "metal"
    if "ardoise" in value:
        return "slate"
    if "tuile" in value or "terre cuite" in value:
        return "tile"
    if "beton" in value or "ciment" in value or "terrasse" in value:
        return "concrete"
    if "bois" in value:
        return "wood"
    return ""


def _coordinates(geometry):
    """A GeoJSON Polygon or MultiPolygon as mapgeom's polygon parts, plus its bbox centre."""
    if not isinstance(geometry, dict):
        return None
    kind = geometry.get("type")
    coords = geometry.get("coordinates")
    if kind == "Polygon":
        polygons = [coords]
    elif kind == "MultiPolygon":
        polygons = coords
    else:
        return None
    if not isinstance(polygons, list):
        return None
    parts = []
    all_xy = []
    for polygon in polygons:
        if not isinstance(polygon, list):
            continue
        rings = []
        for raw in polygon:
            try:
                ring = np.asarray(raw, dtype=np.float64)
            except (TypeError, ValueError):
                continue
            if ring.ndim != 2 or ring.shape[1] < 2 or len(ring) < 4:
                continue
            ring = np.ascontiguousarray(ring[:, :2])
            if not np.isfinite(ring).all():
                continue
            rings.append(ring)
            all_xy.append(ring)
        if rings:
            parts.append(rings)
    if not parts or not all_xy:
        return None
    xy = np.concatenate(all_xy, axis=0)
    centre = ((float(xy[:, 0].min()) + float(xy[:, 0].max())) / 2.0,
              (float(xy[:, 1].min()) + float(xy[:, 1].max())) / 2.0)
    return (mg.POLYGON, parts), centre


def _features(rows):
    """Decode WFS rows into the common buildings schema; sorted and deduplicated by IGN id."""
    decoded = {}
    for feature in rows:
        if not isinstance(feature, dict):
            continue
        properties = feature.get("properties") or {}
        if not isinstance(properties, dict):
            continue
        state = _norm(properties.get("etat_de_l_objet"))
        if state in ("en projet", "en construction"):
            continue
        ident = properties.get("cleabs") or feature.get("id")
        if not ident:
            continue
        geometry = _coordinates(feature.get("geometry"))
        if geometry is None:
            continue
        geom, centre = geometry
        floors = _number(properties.get("nombre_d_etages"))
        height = _number(properties.get("hauteur"))
        raw = dict(properties)
        decoded[str(ident)] = (geom, centre, raw, floors, height)

    ids = sorted(decoded)
    feats = mg.build("buildings", [f"ign:{ident}" for ident in ids], [decoded[i][0] for i in ids])
    centres = [decoded[i][1] for i in ids]
    props = [decoded[i][2] for i in ids]
    floors = [decoded[i][3] for i in ids]
    heights = [decoded[i][4] for i in ids]
    n = len(ids)

    feats.attrs["cx"] = mg.float_column([p[0] for p in centres], np.float64)
    feats.attrs["cy"] = mg.float_column([p[1] for p in centres], np.float64)
    feats.attrs["subtype"] = mg.text_column([p.get("nature") for p in props])
    feats.attrs["class"] = mg.text_column([_building_class(p, f) for p, f in zip(props, floors)])
    feats.attrs["name"] = mg.text_column([""] * n)
    feats.attrs["src_dataset"] = mg.text_column(["IGN BD TOPO"] * n)
    feats.attrs["src_record"] = mg.text_column([str(p.get("cleabs") or "") for p in props])
    feats.attrs["roof_shape"] = mg.text_column([""] * n)
    feats.attrs["roof_orientation"] = mg.text_column([""] * n)
    feats.attrs["roof_material"] = mg.text_column([_roof_material(p.get("materiaux_de_la_toiture")) for p in props])
    feats.attrs["roof_color"] = mg.text_column([""] * n)
    feats.attrs["facade_material"] = mg.text_column([_wall_material(p.get("materiaux_des_murs")) for p in props])
    feats.attrs["facade_color"] = mg.text_column([""] * n)
    feats.attrs["height_src"] = mg.text_column(["IGN BD TOPO" if h is not None else "" for h in heights])
    feats.attrs["height"] = mg.float_column(heights)
    feats.attrs["min_height"] = mg.float_column([None] * n)
    feats.attrs["num_floors"] = mg.float_column(floors)
    feats.attrs["num_floors_underground"] = mg.float_column([None] * n)
    feats.attrs["min_floor"] = mg.float_column([None] * n)
    feats.attrs["level"] = mg.float_column([None] * n)
    feats.attrs["roof_height"] = mg.float_column([None] * n)
    feats.attrs["roof_direction"] = mg.float_column([None] * n)
    feats.attrs["is_underground"] = mg.bool_column([False] * n)
    feats.attrs["has_parts"] = mg.bool_column([False] * n)
    return feats


def query(cell, fetcher, kind="demand"):
    """Fetch one complete cell of official building polygons and return mapgeom.Features."""
    bounds = cell.bounds()
    first = _fetch(fetcher, bounds, 0, kind)
    try:
        matched = int(first.get("numberMatched", len(first["features"])))
    except (TypeError, ValueError, OverflowError):
        matched = len(first["features"])
    if matched < 0 or matched > MAX_FEATURES_PER_CELL:
        raise Error(f"unexpected IGN feature count in {cell}: {matched}")
    rows = list(first["features"])
    if matched > PAGE_SIZE:
        start = len(rows)
        while start < matched:
            page = _fetch(fetcher, bounds, start, kind)["features"]
            if not page:
                raise Error(f"incomplete IGN response in {cell}: stopped at {start} of {matched}")
            rows.extend(page)
            start += len(page)
            if start > MAX_FEATURES_PER_CELL:
                raise Error(f"IGN response exceeded the cell limit in {cell}")
    if len(rows) < matched:
        raise Error(f"incomplete IGN response in {cell}: received {len(rows)} of {matched}")
    feats = _features(rows)
    log.debug("BD TOPO buildings %s: %d features (%d WFS rows)", cell, len(feats), len(rows))
    return feats


def provenance(count):
    """Attribution record stored alongside the cached cell layer."""
    return {
        "id": "ign-bdtopo-buildings", "name": "IGN BD TOPO buildings", "release": RELEASE,
        "attribution": "© IGN, BD TOPO",
        "licence": "Licence Ouverte / Open Licence 2.0 (Etalab)",
        "url": "https://geoservices.ign.fr/bdtopo",
        "features": int(count),
    }
