"""Street furniture (the user, 2026-10-13: "make the world look alive"): street lights along the sidewalks
of town streets and wooden utility poles along country roads, placed per road tile with the road tile's
geometry (roads.build_tile) and shown by the mod as Forest items (trees.lua groups "streetlight", "pole").

Spacing from the stock maps and US practice: West Coast USA's lamps stand ~17 m from their nearest
neighbour (often across the street; ~30-40 m along one side), residential streets in US towns light one
side every ~35-45 m, arterials both sides staggered every ~30 m; utility poles every ~40-50 m on one side.
Each road's lamps sit at fixed distances along the road from its first vertex with a phase hashed from the
road's id, so every tile (and every anchor) puts them in the same places (ROADMAP "deterministic
generation"). Pure.
"""
import hashlib
import math

import numpy as np

# class: (spacing m along one side, both sides staggered: a lamp every half that along the road). Measured (the user,
# 2026-10-27: "check that they are realistically spaced apart") from OpenStreetMap's mapped street lamps (Overture
# infrastructure street_lamp, matched to the nearest street, gaps along it): Prague, Warsaw, Szeged and Utrecht's main
# roads ~30 m, their residential streets 25-30 m, nearly all on one side (the wide ones: both, or the median).
LAMP_SPACING = {"trunk": (60.0, True), "primary": (60.0, True), "secondary": (30.0, False), "tertiary": (30.0, False),
                "residential": (28.0, False), "unclassified": (32.0, False), "living_street": (25.0, False)}
# North America (LAMP_REGIONS "na"): the cities' design standards, sparser: arterials 200-250 ft along a side,
# staggered (Phoenix; San Antonio 150-200 ft), collectors 250 ft staggered (Queen Creek AZ), local streets 250-300 ft
# (Liberty MO, Moorhead MN; Queen Creek up to 500 ft); on utility poles every other pole (TOWN_POLE_SPACING x 2)
LAMP_SPACING_NA = {"trunk": (70.0, True), "primary": (70.0, True), "secondary": (76.0, True), "tertiary": (76.0, False),
                   "residential": (76.0, False), "unclassified": (90.0, False), "living_street": (45.0, False)}
# ... and their dense cores (a tile not `town`: building coverage POLES_COVERAGE or more) closer on the side streets:
# Washington DC 60-150 ft (DDOT), Columbus' post tops 150-170 ft, Chicago's davits opposite or staggered
LAMP_SPACING_NA_DENSE = dict(LAMP_SPACING_NA, residential=(46.0, False), unclassified=(50.0, False),
                             living_street=(40.0, False))
LAMP_REGIONS = {"US": "na", "CA": "na"}
# US states' own practice (the state DOTs' lighting policies and their largest cities' design manuals, researched
# 2026-10-27: .claude/work/street_lighting_research.md):
# - the Mountain West and Oklahoma light single-family local streets at their intersections, mid-block only past
#   300-600 ft (Salt Lake City, Denver, Boise, Oklahoma City; Elko 350-500 ft, Las Cruces 250-400 ft): "na:sparse"
# - California, Oregon, Washington and Virginia light their freeways at the interchanges only (ramp gores, merges and
#   terminals; "nodes, not roads": VDOT), never the urban mainline as the Midwest's, Texas' and Florida's metros do:
#   "na:ramps"
US_SPARSE_LOCAL = {"UT", "CO", "ID", "NV", "OK", "MT", "WY", "NM"}
US_RAMPS_ONLY = {"CA", "OR", "WA", "VA"}
LAMP_SPACING_NA_SPARSE = dict(LAMP_SPACING_NA, residential=(130.0, False), unclassified=(150.0, False),
                              living_street=(60.0, False))
LAMP_SPACING_NA_SPARSE_DENSE = dict(LAMP_SPACING_NA_DENSE, residential=(60.0, False), unclassified=(66.0, False))




def _owns(box, x, y):
    """Is (x, y) the tile's own point (geotiles.box_owns: a geotile's exactly, an anchor tile's half-open box)?"""
    import geotiles
    return geotiles.box_owns(box, x, y)

def lamp_region(country, region=None):
    """The street lamp rules of a country (ISO 3166 alpha-2) and region (ISO 3166-2, e.g. "US-CA"): "na",
    "na:sparse" or "na:ramps" (LAMP_SPACING_NA and the states' practice) or None (LAMP_SPACING)."""
    r = LAMP_REGIONS.get(str(country or "").upper())
    state = str(region or "").upper().partition("-")[2]
    if r == "na" and str(country or "").upper() == "US":
        if state in US_SPARSE_LOCAL:
            return "na:sparse"
        if state in US_RAMPS_ONLY:
            return "na:ramps"
    return r


def _na(region):
    return str(region or "").startswith("na")


def lamp_spacing(region, dense=False):
    """The class -> (spacing, both) table of a lamp region (dense: a city's core)."""
    if region == "na:sparse":
        return LAMP_SPACING_NA_SPARSE_DENSE if dense else LAMP_SPACING_NA_SPARSE
    if _na(region):
        return LAMP_SPACING_NA_DENSE if dense else LAMP_SPACING_NA
    return LAMP_SPACING


def highway_lit(region, link, urban):
    """Is a highway (HIGHWAY_CLASSES) lit: every ramp (in the country only at its ends: PARTIAL_END_M); the mainline in
    built-up land, except where the state lights its interchanges only."""
    return bool(link) or (bool(urban) and region != "na:ramps")
LAMP_CURB_M = 0.5           # m from the curb onto the sidewalk
POLE_SPACING = 45.0
POLE_CLASSES = {"secondary", "tertiary", "residential", "unclassified"}
POLE_OFF_M = 2.4            # m beyond the carriageway's edge
END_CLEAR_M = 4.0           # m kept clear of a run's ends (corners, crosswalk ramps)
CLEAR_OTHER_M = 1.5         # m kept off another road's carriageway
G_LAMP, G_POLE = "streetlight", "pole"


def _h01(*vals):
    h = hashlib.blake2b(repr(vals).encode(), digest_size=8).digest()
    return int.from_bytes(h, "little") / 2.0 ** 64


def _arclen(p):
    d = np.hypot(*np.diff(p[:, :2], axis=0).T)
    return np.concatenate([[0.0], np.cumsum(d)])


def _project(line, q):
    """Arc length along polyline line (k, 2+) of the nearest point to each q (m, 2)."""
    a, b = line[:-1, :2], line[1:, :2]
    d = b - a
    L2 = np.maximum((d * d).sum(1), 1e-12)
    t = np.clip(((q[:, None, :] - a[None]) * d[None]).sum(2) / L2[None], 0, 1)
    p = a[None] + t[..., None] * d[None]
    dist = np.hypot(*(q[:, None, :] - p).transpose(2, 0, 1))
    k = dist.argmin(1)
    s = _arclen(line)
    return s[k] + t[np.arange(len(q)), k] * np.sqrt(L2[k])


def _at(line, s):
    """Points (and unit directions) at arc lengths s along line (k, 3)."""
    ss = _arclen(line)
    s = np.clip(s, 0, ss[-1])
    k = np.clip(np.searchsorted(ss, s, side="right") - 1, 0, len(line) - 2)
    seg = line[k + 1] - line[k]
    L = np.maximum(ss[k + 1] - ss[k], 1e-9)
    t = (s - ss[k]) / L
    p = line[k] + seg * t[:, None]
    d = seg[:, :2] / L[:, None]
    return p, d


def _yaw(dx, dy):
    """Degrees of a Forest item's rotation that turns its local +x toward (dx, dy) (trees.lua: setFromEuler
    with -yaw about z, the engine's clockwise headings)."""
    return math.degrees(math.atan2(dy, dx)) % 360.0


def _clear(p, others, own):
    import fast
    if not isinstance(others, fast.Others):
        others = fast.Others(others)
    return bool(others.clear(p, own, CLEAR_OTHER_M))


WIRE_ARMS = (-0.8, 0.0, 0.8)    # m along the cross-arm (the pole's local x) of the three wires
WIRE_Z = 7.9                    # m above the pole's base (s_powerpole_3wire: 8.2 m tall above its origin)
WIRE_SAG = 0.012                # sag per metre of span
WIRE_SEG_M = 5.0
WIRE_R = 0.012                  # m half width of a wire's ribbons
WIRE_VERTS_MAX = 60000          # a tile's wire mesh at most (the engine's 16-bit index buffers; railways.VERTS_MAX)


def wire_lines(poles):
    """Polylines (k, 3) of the wires between consecutive poles [(x, y, z, yaw_deg)] of one road side."""
    out = []
    for (x0, y0, z0, w0), (x1, y1, z1, w1) in zip(poles[:-1], poles[1:]):
        span = math.hypot(x1 - x0, y1 - y0)
        if span < 5.0 or span > 80.0:
            continue
        k = max(2, int(math.ceil(span / WIRE_SEG_M)))
        t = np.linspace(0.0, 1.0, k + 1)
        for off in WIRE_ARMS:
            a = np.array([x0 + math.cos(math.radians(w0)) * off, y0 + math.sin(math.radians(w0)) * off, z0 + WIRE_Z])
            b = np.array([x1 + math.cos(math.radians(w1)) * off, y1 + math.sin(math.radians(w1)) * off, z1 + WIRE_Z])
            p = a[None] + (b - a)[None] * t[:, None]
            p[:, 2] -= 4.0 * WIRE_SAG * span * t * (1.0 - t)
            out.append(p)
    return out


def wire_mesh(lines, origin):
    """A mesh of the wires (each its points, or (points, half width): WIRE_R when not given): two crossed ribbons per
    segment (seen from any side): (positions, tris, uvs)."""
    P, T = [], []
    ox, oy, oz = origin
    for line in lines:
        line, r = line if isinstance(line, tuple) else (line, WIRE_R)
        if len(P) + 8 * (len(line) - 1) > WIRE_VERTS_MAX:       # (8 vertices a segment; the rest left out)
            break
        for a, b in zip(line[:-1], line[1:]):
            d = b - a
            L = float(np.linalg.norm(d))
            if L < 1e-6:
                continue
            d /= L
            # (np.cross written out: the same products and differences, without its per-call cost)
            side = np.array([d[1] * 1.0 - d[2] * 0.0, d[2] * 0.0 - d[0] * 1.0, d[0] * 0.0 - d[1] * 0.0])
            side = side / (np.linalg.norm(side) or 1.0) * r
            up = np.array([side[1] * d[2] - side[2] * d[1], side[2] * d[0] - side[0] * d[2],
                           side[0] * d[1] - side[1] * d[0]])
            up = up / (np.linalg.norm(up) or 1.0) * r
            for v in (side, up):
                i = len(P)
                P += [a - v, b - v, b + v, a + v]
                T += [(i, i + 1, i + 2), (i, i + 2, i + 3), (i, i + 2, i + 1), (i, i + 3, i + 2)]
    if not P:
        return None
    P = np.array(P) - np.array([ox, oy, oz])
    return P, np.array(T, np.int64), np.zeros((len(P), 2))


MAJOR = {"primary", "secondary", "tertiary", "trunk"}
MINOR = {"residential", "unclassified", "living_street"}
G_SIGNAL, G_STOP, G_YIELD = "signal", "stop", "giveway"
JUNCTION_SNAP_M = 1.0       # road ends this close are one junction


def _arms(roads):
    """Junctions: {(x, y) rounded: [(fid, spec, unit vector away from the junction, point, at its start, road
    length), ...]} of road ends that meet (Overture splits segments at their connectors)."""
    ends = {}
    for fid, spec, pts, _ in roads:
        if len(pts) < 2:
            continue
        length = float(np.sum(np.hypot(*np.diff(pts[:, :2], axis=0).T)))
        for p, q, start in ((pts[0], pts[1], True), (pts[-1], pts[-2], False)):
            d = q[:2] - p[:2]
            L = float(np.hypot(*d))
            if L < 1e-3:
                continue
            k = (round(float(p[0]) / JUNCTION_SNAP_M), round(float(p[1]) / JUNCTION_SNAP_M))
            ends.setdefault(k, []).append((fid, spec, d / L, p, start, length))
    return ends


LINK_M = 30.0           # a road this short joining two signalled junctions is a link inside one intersection (the
                        # crossing of a divided road's median): no signal on it


def _outbound(a):
    """Does traffic on arm a (fid, spec, u, p[, at its start[, length]]) only leave the junction (one-way away)?"""
    if len(a) < 5 or not a[1].oneway or not getattr(a[1], "dir", 0):
        return False
    return (a[1].dir > 0) == bool(a[4])


SIGNAL_NEAR_M = 25.0        # m past the junction's widest arm a mapped traffic signal may stand (OSM maps them at the
                            # junction's node or at each approach's stop line)


def mapped_signals(frame, infra_list):
    """(n, 2) frame xy of OpenStreetMap's traffic signals (Overture infrastructure transportation/traffic_signals) in
    infra_list (infrastructure Features of map cells, duplicates taken once); None when no layer could be read (the
    junctions then fall back to _guess_signalled)."""
    if not infra_list or all(f is None for f in infra_list):
        return None
    seen, ll = set(), []
    for f in infra_list:
        if f is None or len(f) == 0:
            continue
        cls, sub = f.attrs.get("class"), f.attrs.get("subtype")
        if cls is None:
            continue
        # (whole arrays: a city cell has thousands of infrastructure features and a road tile reads ~9 cells)
        hit = np.asarray(cls).astype(str) == "traffic_signals"
        if sub is not None:
            hit &= np.asarray(sub).astype(str) == "transportation"
        for i in np.flatnonzero(hit):
            fid = str(f.ids[i])
            if fid in seen:
                continue
            seen.add(fid)
            a = f.coord_off[f.ring_off[f.part_off[i]]]
            b = f.coord_off[f.ring_off[f.part_off[i + 1]]]
            ll.append(f.lonlat[a:b].mean(axis=0))
    if not ll:
        return np.zeros((0, 2))
    ll = np.asarray(ll, np.float64)
    e, n, _ = frame.geodetic_to_enu(ll[:, 1], ll[:, 0], 0.0)
    return np.column_stack([np.asarray(e), np.asarray(n)])


def signals_for(md, frame, keys):
    """mapped_signals of the map cells keys (md: mapdata.MapData), None when their infrastructure cannot be read."""
    try:
        return mapped_signals(frame, [md.cell(k, layers=("infrastructure",), kind="demand").layers.get("infrastructure")
                                      for k in keys])
    except Exception as e:      # guessed signals rather than no road tile
        import logging
        logging.getLogger("earthd.furniture").debug("traffic signals: %s: %s", type(e).__name__, e)
        return None


def _guess_signalled(arms):
    major = [a for a in arms if a[1].cls in MAJOR]
    return len(major) >= 3 or (len(major) >= 2 and len(arms) >= 4)


def _is_signalled(arms, signals=None):
    """Traffic lights at this junction: a mapped signal (signals: mapped_signals' points) within SIGNAL_NEAR_M of its
    widest arm's edge; with no map data (None), where two or more major roads meet (the user, 2026-10-25: lights where
    there are none)."""
    if signals is None:
        return _guess_signalled(arms)
    if not len(signals):
        return False
    c = np.array([sum(float(a[3][0]) for a in arms), sum(float(a[3][1]) for a in arms)]) / len(arms)
    reach = max(a[1].width for a in arms) / 2 + SIGNAL_NEAR_M
    return bool((np.hypot(signals[:, 0] - c[0], signals[:, 1] - c[1]) <= reach).any())


def junction_controls(arms, k, link_ok=None, ring=None, signals=None):
    """[(arm, G_SIGNAL | G_STOP | G_YIELD)] of a junction's arms (fid, spec, unit vector away, point): signals on
    every arm where two or more major roads meet, stop signs on the minor arms meeting a major road, on the
    stem of a minor T and on half the minor four-ways (hashed by the roads meeting there; k is unused). Shared with
    navgraph.py, so the AI's signals and stop signs are where the props stand. ring: the fids of roundabout rings
    (islands.ring_fids): a junction on a ring (two of its arms) has give-way signs on incoming external arms.
    The AI graph handles their priority, without installing stop controllers on the ring. signals: the mapped
    traffic signals near (mapped_signals; None: guessed by the roads' classes)."""
    if ring and sum(1 for a in arms if a[0] in ring) >= 2:
        return [(a, G_YIELD) for a in arms if a[0] not in ring and not _outbound(a)]
    major = [a for a in arms if a[1].cls in MAJOR]
    minor = [a for a in arms if a[1].cls in MINOR]
    if _is_signalled(arms, signals):
        # one head per way in: none on a one-way arm leaving it, none on a short link to the next signalled
        # junction (a divided road crossing a street is two junctions 20 m apart: the user's report 2026-10-14,
        # Boston St, "way too many traffic lights"); link_ok(arm) says whether that link's far end is signalled
        return [(a, G_SIGNAL) for a in arms if a[1].cls in MAJOR | MINOR and not _outbound(a)
                and not (link_ok is not None and len(a) >= 6 and a[5] < LINK_M and link_ok(a))]
    if major:
        return [(a, G_STOP) for a in minor]
    if len(arms) == 3:
        # the stem: the arm least in line with another
        def straightest(a):
            return max(-float(a[2] @ b[2]) for b in arms if b is not a)
        return [(min(arms, key=straightest), G_STOP)] if all(a[1].cls in MINOR for a in arms) else []
    # the all-way coin flip: keyed on the roads that meet there (their map ids, sorted: the arms' order differs between
    # the road tiles and the road graph), the same from both and from every anchor (an 8 m cell of the junction in
    # the anchor's frame flipped junctions at a rebase: geotiles, 2026-10-29)
    key = tuple(sorted(str(a[0]) for a in arms))
    return [(a, G_STOP) for a in minor] if _h01("allway", key) < 0.5 else []


def _link_check(junctions, signals=None):
    """link_ok(arm) for junction_controls: is the junction at the other end of arm's road a signalled urban one?"""
    where = {}                                  # (fid, at start) -> the junction's arms
    for arms in junctions.values():
        for a in arms:
            where[(a[0], a[4])] = arms
    def link_ok(a):
        other = where.get((a[0], not a[4]))
        return other is not None and len(other) >= 3 and _controlled_here(other, signals) and \
            _is_signalled(other, signals)
    return link_ok


def _controlled_here(arms, signals=None):
    """Does a junction get signals or signs at all: in town (every arm urban), or anywhere a signal is mapped at it."""
    return all(a[1].urban for a in arms) or (signals is not None and _is_signalled(arms, signals))


SIGN_CLEAR_M = 0.6          # m a junction sign stands clear of every carriageway's edge


def _off_carriageways(c, u, right, along, out, lines):
    """The point along m past the junction c along u and out m to the right, moved further along and out (up to
    10 m and 3 m) until it is SIGN_CLEAR_M clear of every carriageway in lines [(half width, centreline)]; None
    when nowhere is: stop signs and signals stood in the middle of a wide road beside the junction (Boston Street,
    Baltimore, the user's report 2026-10-17: 6 in one tile)."""
    for da in (0.0, 2.0, 4.0, 6.0, 8.0, 10.0):
        for do in (0.0, 1.0, 2.0, 3.0):
            q = c + u * (along + da) + right * (out + do)
            if all(_seg_dist_min(q, ln) >= h + SIGN_CLEAR_M for h, ln in lines):
                return q
    return None


def _seg_dist_min(p, line):
    a, b = line[:-1], line[1:]
    d = b - a
    L2 = np.maximum((d * d).sum(1), 1e-12)
    t = np.clip(((p - a) * d).sum(1) / L2, 0, 1)
    return float(np.hypot(*(a + t[:, None] * d - p).T).min())


def signal_spot(c, u, right, wide, half, lines):
    """Where an approach's signal or sign stands at junction point c (arm direction u away from it, right: the kerb
    side): past the junction's widest arm (wide: its half width) and outside the approach's carriageway (half), moved
    off every carriageway in lines [(half width, centreline (k, 2))], bridge decks included (a signal pole stood on a
    ramp's deck where it comes down to Fallsway, Baltimore, and a car hit it, 2026-10-21); None when nowhere is clear.
    junction_props' props and navgraph's switchable heads (which stand in for them) both stand here."""
    c = np.asarray(c, np.float64)[:2]
    near = [(h, ln) for h, ln in lines if len(ln) >= 2 and np.hypot(*(ln - c).T).min() < 80.0]
    return _off_carriageways(c, u, right, wide + 2.5, half + 1.0, near)


def junction_props(roads, box, curb_h=0.15, left_hand=False, decks=(), signals=None):
    """Signals at the junctions with a mapped traffic signal (signals: mapped_signals'; None: at urban junctions of
    two or more major roads), stop signs at urban junctions
    of minor roads (the minor arms meeting a major road; the stem of a T; half the four-way ones, hashed).
    Each on the approach's right (its left where traffic drives on the left), at the junction's edge, facing
    the drivers who come in. decks: [(centreline (k, 3), half width)] of the bridge decks near (signal_spot)."""
    x0, y0, x1, y1 = box
    rows = []
    junctions = _arms(roads)
    link_ok = _link_check(junctions, signals)
    import islands
    ring = islands.ring_fids(roads)
    lines = [(spec.width / 2, np.asarray(pts, np.float64)[:, :2]) for _, spec, pts, _ in roads if len(pts) >= 2]
    lines += [(float(h), np.asarray(pts, np.float64)[:, :2]) for pts, h in decks if len(pts) >= 2]
    for k, arms in junctions.items():
        on_ring = sum(1 for a in arms if a[0] in ring) >= 2
        if len(arms) < 3 or (not on_ring and not _controlled_here(arms, signals)):
            continue
        p = arms[0][3]
        if not (_owns(box, p[0], p[1])):
            continue
        put = junction_controls(arms, k, link_ok, ring, signals)
        if not put:
            continue
        wide = max(a[1].width for a in arms) / 2
        for (fid, spec, u, c, *_), what in put:
            # the approach comes in along -u; its right is (-u_y, u_x)... rotated: right of travel (-u)
            inc = -u
            right = np.array([inc[1], -inc[0]]) * (-1 if left_hand else 1)     # the kerb side of the approach
            q = signal_spot(c, u, right, wide, spec.width / 2, lines)
            if q is None or not (x0 - 20 <= q[0] < x1 + 20 and y0 - 20 <= q[1] < y1 + 20):
                continue
            rows.append([what, round(float(q[0]), 2), round(float(q[1]), 2), round(float(c[2] + curb_h), 2),
                         round(_yaw(right[0], right[1]), 1), 1.0, 9.4 if what == G_SIGNAL else 3.0, 0.0])
    return rows


# The mod's round km/h sign models (trees.lua's speedk<n>, tools/generate_kmh_speed_signs.py; PR #195). Not placed since
# 2026-10-28: the speed-limit signs are the sign tiles' (speedsigns.py: where the limit changes, past major junctions,
# drawn in each region's style), which replaced the props that stood 30 m after both ends of every long segment.
SIGN_KMH = (30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150)


G_HYDRANT, G_BENCH, G_BIN = "hydrant", "bench", "bin"
G_STREET_TREE = "deciduous"     # trees.lua's broadleaf group (the variant nearest each tree's height)
STREET_TREE_CLASSES = {"residential", "tertiary", "secondary", "living_street"}
STREET_TREE_SHARE = 0.5         # streets with a row of trees (hashed per street)
STREET_TREE_SPACING = 11.0
STREET_TREE_CURB_M = 0.9
G_POLELAMP = "polelamp"     # a cobra-head arm on a utility pole (East Coast USA's electrical_pole_lamp)
# The share of a country's low-voltage lines that are underground (the user, 2026-10-26: "Currently we've been placing
# them almost everywhere"): the European Commission's "Overview of the Potential for Undergrounding the Electricity
# Networks in Europe" (ICF Consulting, 2003; Europacable / Sycabel km of overhead and underground LV line, ~2000), the
# underground share of each country's low-voltage km. Countries not listed: mostly overhead (the US, Canada, Japan,
# Australia, most of the world). Old figures: the shares have only grown since.
BURIED_LV = {"NL": 1.0, "GB": 0.81, "DE": 0.75, "DK": 0.65, "BE": 0.44, "NO": 0.38, "IT": 0.30, "FR": 0.27,
             "PT": 0.19, "AT": 0.15, "ES": 0.14}


def buried_share(country):
    """The share of the country's (ISO 3166 alpha-2) low-voltage lines underground (BURIED_LV), else 0."""
    return BURIED_LV.get(str(country or "").upper(), 0.0)
# The lamps' lenses (night lighting: nightlights.lua lights their material after dusk and puts its lights at them;
# tools/build_lamp_lens.py): the stock heads' glass is a material every building's windows share. At each lamp's glass
# (the centroid of its transparent vertices in the stock mesh, its local frame: x along the row's yaw; measured by
# MihneaTeodorStoica for PR #340), LENS_DROP_M under it.
G_LENS = "lamplens"
# and a glow at each (tools/build_lamp_glow.py: a ball growing with distance, drawn at night only, so lamps show far off)
G_GLOW = "lampglow"
LAMP_HEADS = {G_LAMP: (2.71130, -0.00032, 7.95393), G_POLELAMP: (-2.67592, 0.00012, 0.43511)}
LENS_DROP_M = 0.03
TOWN_POLE_CLASSES = {"residential", "tertiary", "unclassified", "secondary", "living_street", "primary", "trunk"}
TOWN_POLE_SPACING = 40.0
# the main roads' poles carry a lamp each; the others every other pole in North America (~260 ft: its local streets'
# 250-300 ft), every pole elsewhere (OpenStreetMap's mapped lamps: 25-30 m on residential streets)
POLE_LAMP_EVERY = {"trunk", "primary", "secondary"}


def pole_lamp(cls, k, region):
    """Does the k-th utility pole along a road of class cls carry a lamp? (the sparse states: every third)"""
    if cls in POLE_LAMP_EVERY or not _na(region):
        return True
    return k % (3 if region == "na:sparse" else 2) == 0
# a town street without a mapped sidewalk: its lamps at the carriageway's edge (on its poles, or posts where the lines
# are buried) LAMP_EDGE_M beyond it (the user, 2026-10-27: lamps only near the camera; Potee Street's streets had
# lamps on a quarter of their length: only where a sidewalk was mapped)
LAMP_EDGE_M = 1.2
# highways (the user, 2026-10-27: "make sure highways have street lights"): in built-up land, and every ramp, lamp posts
# along each carriageway's outer edge (a divided road's two one-way ways: both sides lit, nothing in the median)
# (US freeways: 40-50 ft poles 220-270 ft apart, TxDOT's lighting manual; elsewhere closer and lower; the stock post
# scaled to HIGHWAY_LAMP_H)
HIGHWAY_CLASSES = {"motorway", "trunk"}
HIGHWAY_LAMP_SPACING = {"na": 70.0, None: 45.0}
LINK_LAMP_SPACING = {"na": 60.0, None: 40.0}
PARTIAL_END_M = 15.0        # m from a rural ramp's ends its two lamps stand (partial interchange lighting, FHWA Lighting
                            # Handbook 2012 / AASHTO: luminaires at the gores and the ramp terminals only; every rural
                            # ramp lit end to end put 27 lamps on a Wyoming interchange of I-80, Discord 2026-10-28)
HIGHWAY_LAMP_H = {"na": 13.5, None: 11.0}         # (ramps: the street post, NJDOT's 26 ft on ramps)
LAMP_H = {G_LAMP: 9.0, "polelamp": 1.1}    # the catalog's heights (trees.lua CATALOG): a row's height over it, its scale
POLE_LAMP_Z = 7.0           # m above the pole's base
HYDRANT_SPACING = 120.0
BENCH_SPACING = 140.0
BIN_SPACING = 90.0
BENCH_YAW = 90.0            # the bench model's front is its local +y (the yaw puts +x toward the road)


def lamp_lenses(rows):
    """A lens row [G_LENS, x, y, z, yaw, 1, 1, 0] under the head of every lamp row (LAMP_HEADS; its scale: the row's
    height over the catalog's, 1 for both), and a G_GLOW row at the same place."""
    out = []
    for r in rows:
        head = LAMP_HEADS.get(r[0])
        if head is None:
            continue
        a = math.radians(r[4])
        c, s_ = math.cos(a), math.sin(a)
        k = r[6] / LAMP_H.get(r[0], r[6]) if r[6] else 1.0     # (a scaled lamp: its head scaled alike)
        hx, hy, hz = head[0] * k, head[1] * k, head[2] * k
        lens = [G_LENS, round(r[1] + c * hx - s_ * hy, 2), round(r[2] + s_ * hx + c * hy, 2),
                round(r[3] + hz - LENS_DROP_M, 2), r[4], 1.0, 1.0, r[7]]
        out += [lens, [G_GLOW] + lens[1:]]
    return out


def _stations(run, line, spacing, phase, clear, side):
    """(point (3,), away-from-the-road unit (2,)) on a sidewalk run at the road's stations phase + k spacing
    (arc length along the road line, so every tile and anchor gets the same ones), END_CLEAR_M from the run's
    ends."""
    s_run = _project(line, run[:, :2])
    lo, hi = min(s_run[0], s_run[-1]), max(s_run[0], s_run[-1])
    k0, k1 = math.ceil((lo - phase) / spacing), math.floor((hi - phase) / spacing)
    if k1 < k0:
        return []
    p_road, _ = _at(line, phase + spacing * np.arange(k0, k1 + 1))
    s_on_run = _project(run, p_road[:, :2])
    L = _arclen(run)[-1]
    out = []
    for s in s_on_run:
        if s < clear or s > L - clear:
            continue
        p, d = _at(run, np.array([s]))
        out.append((p[0], np.array([-d[0][1], d[0][0]]) * side))   # away from the road (sidewalks.run_geometry)
    return out


DECK_HEADROOM_M = 0.5      # m a prop's top stays below a bridge deck over it
DECK_SIDE_M = 1.0          # m beside a deck's edge that still counts as under it
DECK_WIRE_M = 1.5          # m a wire stays below a deck over it


def under_decks(rows, decks, wires=None):
    """rows without the props that would reach up into a bridge deck above them (a road's lamps and poles
    under a motorway bridge stood 9 m tall through its deck: a car hit one at 75 mph on I-80, 2026-10-15).
    decks: [(points (k, 3) of the deck's centreline, half width)]. wires: removed in place where one passes
    under a deck closer than the headroom."""
    if not decks:
        return rows
    segs = []
    for pts, half in decks:
        p = np.asarray(pts, np.float64)
        if len(p) >= 2:
            segs.append((p[:-1], p[1:], half + DECK_SIDE_M))

    def deck_z(x, y):
        """The lowest deck surface over (x, y), or None."""
        best = None
        for a, b, reach in segs:
            d = b[:, :2] - a[:, :2]
            L2 = np.maximum((d * d).sum(1), 1e-12)
            t = np.clip(((np.array([x, y]) - a[:, :2]) * d).sum(1) / L2, 0, 1)
            q = a[:, :2] + t[:, None] * d
            near = np.hypot(q[:, 0] - x, q[:, 1] - y) < reach
            if near.any():
                z = float((a[:, 2] + t * (b[:, 2] - a[:, 2]))[near].min())
                best = z if best is None else min(best, z)
        return best
    out = []
    for r in rows:
        z = deck_z(r[1], r[2])
        if z is not None and r[3] < z and r[3] + r[6] > z - DECK_HEADROOM_M:
            continue
        out.append(r)
    if wires is not None:
        keep = []
        for w in wires:
            w = np.asarray(w, np.float64)
            hit = False
            for x, y, wz in w[:, :3]:
                z = deck_z(x, y)
                if z is not None and wz > z - DECK_WIRE_M:     # through the deck, or just under it
                    hit = True
                    break
            if not hit:
                keep.append(w)
        wires[:] = keep
    return out


def place(roads, walks, box, curb_h=0.15, wires=None, town=False, left_hand=False, decks=(),
          signals=None, buried=0.0, region=None, lighting=None):
    """Rows [group, x, y, z, yaw, scale, height, rank] (trees.lua's tile rows) of the lamps and poles of a
    tile box (x0, y0, x1, y1). roads: build_tile's (fid, spec, centreline (k, 3), lon); walks: its sidewalk
    runs (dicts with fid, pts, side, w); decks: the bridge decks over the tile [(centreline (k, 3), half
    width)]: nothing tall under them (under_decks). buried: the share of the country's low-voltage lines that are
    underground (buried_share): that share of the roads (hashed) get no utility poles (a town's street its lamps
    instead). region: lamp_region's (the lamps' spacing)."""
    spacing_of = lamp_spacing(region, dense=not town)
    lighting = lighting or {}  # OSM way lighting; absent/unknown keeps the inferred rule
    x0, y0, x1, y1 = box
    by_fid = {fid: (spec, pts) for fid, spec, pts, _ in roads}

    def overhead(fid):          # does this road's line run on poles (not buried)?
        return _h01(fid, "buried") >= buried
    import fast
    others = fast.Others([(fid, spec.width / 2, pts) for fid, spec, pts, _ in roads])
    rows = []
    lit = set()
    for wk in walks:
        fid = wk.get("fid")
        if fid is None or "pts" not in wk or fid not in by_fid:
            continue
        if wk.get("median"):        # a divided road's median: no lamps, poles, benches or bins on it (Boston
            continue                # Street's is a bare curb, Mapillary 2026-10-17)
        spec, line = by_fid[fid]
        run = np.asarray(wk["pts"], np.float64)
        if len(run) < 2:
            continue
        side = wk["side"]
        w = wk.get("w", 2.5)

        def put(group, spacing, phase, curb_off, height, yaw_fn, clear=END_CLEAR_M):
            for p, out in _stations(run, line, spacing, phase, clear, side):
                q = p[:2] - out * (w / 2 - curb_off)
                if _owns(box, q[0], q[1]):
                    rows.append([group, round(float(q[0]), 2), round(float(q[1]), 2), round(float(p[2] + curb_h), 2),
                                 round(yaw_fn(out), 1), 1.0, height, 0.0])
        rule = spacing_of.get(spec.cls)
        if town and spec.cls in TOWN_POLE_CLASSES and overhead(fid):
            # towns and suburbs: wooden utility poles along one side, wired, a cobra-head lamp on every other
            pole_side = 1 if _h01(fid, "side") < 0.5 else -1
            if side == pole_side:
                lit.add(fid)
                run_poles = []
                ph = _h01(fid, "tphase") * TOWN_POLE_SPACING
                for p, out in _stations(run, line, TOWN_POLE_SPACING, ph, END_CLEAR_M, side):
                    q = p[:2] - out * (w / 2 - 0.6)
                    yaw = _yaw(out[0], out[1])
                    run_poles.append((float(q[0]), float(q[1]), float(p[2]), yaw))
                    if _owns(box, q[0], q[1]):
                        rows.append([G_POLE, round(float(q[0]), 2), round(float(q[1]), 2), round(float(p[2]), 2),
                                     round(yaw, 1), 1.0, 9.2, 0.0])
                        k = int(round((float(_project(line, q[None])[0]) - ph) / TOWN_POLE_SPACING))
                        if lighting.get(fid) != "no" and pole_lamp(spec.cls, k, region):
                            rows.append([G_POLELAMP, round(float(q[0]), 2), round(float(q[1]), 2),
                                         round(float(p[2]) + POLE_LAMP_Z, 2), round(yaw, 1), 1.0, 1.1, 0.0])
                if wires is not None and len(run_poles) > 1:
                    wires.extend(_own_spans(run_poles, box))
            rule = None
        if rule is not None and lighting.get(fid) != "no":
            spacing, both = rule
            lamp_side = 1 if _h01(fid, "side") < 0.5 else -1
            if both or side == lamp_side:
                lit.add(fid)
                phase = _h01(fid, "phase") * spacing + (spacing / 2 if (both and side < 0) else 0.0)
                put(G_LAMP, spacing, phase, LAMP_CURB_M, 9.0, lambda out: _yaw(-out[0], -out[1]))
        if spec.urban and spec.cls in STREET_TREE_CLASSES and _h01(fid, "trees") < STREET_TREE_SHARE:
            # street trees in pits along the curb (the photos' dense streets have rows of them; the canopy
            # model has few there): small broadleaves, both sides, clear of the junctions
            tph = _h01(fid, side, "tph") * STREET_TREE_SPACING
            for p, out in _stations(run, line, STREET_TREE_SPACING, tph, END_CLEAR_M + 4.0, side):
                q = p[:2] - out * (w / 2 - STREET_TREE_CURB_M)
                if _owns(box, q[0], q[1]):
                    # (each tree's size, turn and rank keyed on its station along the road, not on where the anchor's
                    # frame puts it: the same tree from every anchor, geotiles 2026-10-29)
                    k = int(round((float(_project(line, p[None, :2])[0]) - tph) / STREET_TREE_SPACING))
                    h = 6.5 + 3.5 * _h01(fid, side, k, "th")
                    rows.append([G_STREET_TREE, round(float(q[0]), 2), round(float(q[1]), 2), round(float(p[2] + curb_h), 2),
                                 round(_h01(fid, side, k, "ty") * 360.0, 1), 1.0, round(h, 1),
                                 round(_h01(fid, side, k, "tr"), 3)])
        if spec.urban:
            # fire hydrants at the curb (US practice ~90-150 m apart), alternating sides
            put(G_HYDRANT, HYDRANT_SPACING, _h01(fid, "hyd") * HYDRANT_SPACING + (HYDRANT_SPACING / 2 if side < 0 else 0),
                0.45, 0.9, lambda out: _h01(fid, "hy") * 360.0)
        if spec.urban and spec.cls in MAJOR:
            # benches at the back of the sidewalk facing the street, bins at the curb
            put(G_BENCH, BENCH_SPACING, _h01(fid, side, "bench") * BENCH_SPACING, w - 0.45, 0.9,
                lambda out: _yaw(-out[0], -out[1]) + BENCH_YAW)
            put(G_BIN, BIN_SPACING, _h01(fid, side, "bin") * BIN_SPACING, 0.7, 1.1, lambda out: _yaw(-out[0], -out[1]))
    rows.extend(junction_props(roads, box, curb_h, left_hand, decks, signals))
    for fid, spec, line, _ in roads:
        if fid in lit or len(line) < 2:
            continue
        # a street in built-up land (spec.urban: the land cover; the tile's `town` is only "not a dense core", true in
        # the countryside too) with no sidewalk run: lit from its edge; a country road: utility poles alone
        highway = spec.cls in HIGHWAY_CLASSES and (lighting.get(fid) == "yes"
                                                   or highway_lit(region, spec.link, spec.urban))
        lamps = lighting.get(fid) != "no" and (highway or lighting.get(fid) == "yes"
                                                or (spec.urban and spec.cls in TOWN_POLE_CLASSES))
        highway = highway and lamps
        poles = not highway and overhead(fid) and (lamps or (not spec.urban and spec.cls in POLE_CLASSES))
        if not (lamps or poles):
            continue
        side = 1 if _h01(fid, "pside") < 0.5 else -1
        if highway and spec.dir:            # a one-way carriageway: its outer edge (the drivers' right, left-hand: left)
            side = int(spec.dir) if left_hand else -int(spec.dir)
        if highway:
            spacing = (LINK_LAMP_SPACING if spec.link else HIGHWAY_LAMP_SPACING)["na" if _na(region) else None]
        else:
            spacing = ((TOWN_POLE_SPACING if lamps else POLE_SPACING) if poles
                       else spacing_of.get(spec.cls, (HIGHWAY_LAMP_SPACING[None], False))[0])
        phase = _h01(fid, "pphase") * spacing
        L = _arclen(line)[-1]
        s = phase + spacing * np.arange(0, int((L - phase) // spacing) + 1)
        if highway and spec.link and not spec.urban:    # a rural ramp: partial interchange lighting, at its ends
            s = (np.array([PARTIAL_END_M, L - PARTIAL_END_M]) if L > 2 * PARTIAL_END_M + spacing / 2
                 else np.array([L / 2]))
        if not len(s):
            continue
        P, D = _at(line, s)
        run = []
        for k, (p, d) in enumerate(zip(P, D)):
            n = np.array([-d[1], d[0]]) * side
            q = p[:2] + n * (spec.width / 2 + (POLE_OFF_M if poles else LAMP_EDGE_M))
            inside = _owns(box, q[0], q[1])
            if not _clear(np.array([q[0], q[1], p[2]]), others, fid):
                if len(run) > 1 and wires is not None:
                    wires.extend(_own_spans(run, box))
                run = []
                continue
            if not poles:                   # buried lines: lamp posts, their arms over the road
                if inside:
                    h = (HIGHWAY_LAMP_H["na" if _na(region) else None] if highway and not spec.link
                         else LAMP_H[G_LAMP])
                    rows.append([G_LAMP, round(float(q[0]), 2), round(float(q[1]), 2), round(float(p[2]), 2),
                                 round(_yaw(-n[0], -n[1]), 1), 1.0, h, 0.0])
                continue
            # the cross-arm (local x) across the road, the wires (local y) along it
            yaw = _yaw(n[0], n[1])
            run.append((float(q[0]), float(q[1]), float(p[2]), yaw))
            if inside:
                rows.append([G_POLE, round(float(q[0]), 2), round(float(q[1]), 2), round(float(p[2]), 2),
                             round(yaw, 1), 1.0, 9.2, 0.0])
                if lamps and pole_lamp(spec.cls, k, region):
                    rows.append([G_POLELAMP, round(float(q[0]), 2), round(float(q[1]), 2),
                                 round(float(p[2]) + POLE_LAMP_Z, 2), round(yaw, 1), 1.0, 1.1, 0.0])
        if len(run) > 1 and wires is not None:
            wires.extend(_own_spans(run, box))
    return under_decks(rows + lamp_lenses(rows), list(decks), wires)


def _own_spans(run, box):
    """The wires of the spans of a run of poles that start in the tile (each span drawn by one tile)."""
    x0, y0, x1, y1 = box
    out = []
    for a, b in zip(run[:-1], run[1:]):
        if _owns(box, a[0], a[1]):
            out.extend(wire_lines([a, b]))
    return out
