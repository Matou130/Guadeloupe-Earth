"""Speed-limit signs along the roads (the user, 2026-10-28: "speed limit panels could be a good fallback in case osm is
missing data"): the glue of the native kernels earthfast.speed_sign_place (where they stand: changes of the limit,
past major junctions, past motorway entrances, reminders on long stretches) and speed_sign_mesh (MUTCD R2-1 in the
US, Rb-1 in Canada, the Vienna Convention's red ring elsewhere); the rules and their sources are there
(native/earthfast/src/speedsigns.rs).

The value is the AI's (navgraph.road_mph: OpenStreetMap's / Overture's limit, else the class default the traffic
drives), in the units posted there (mph rounded to 5, km/h rounded to 5). Built in the sign tiles (signstream.py,
field "speeds", everywhere, not only in the US), render-only, under the highwaySigns switch.
"""
from functools import lru_cache
import threading

import numpy as np

import exitsigns
import fast
import mapcells
import navgraph
import roads
import signroads

KERNEL = 98                     # earthfast VERSION with speed_sign_place / speed_sign_mesh
RANK = {"motorway": 7, "trunk": 6, "primary": 5, "secondary": 4, "tertiary": 3, "unclassified": 2, "residential": 1}
MARGIN_M = 900.0                # the roads this far round a tile: its junctions and the nearby signs that thin it out
REPEAT_M = (1609.344, 3218.688)  # a reminder about every mile in town and every two out of it (PR #363's 2 miles)
CELL_FRAMES = 4                 # anchors a cell keeps its rows for
STYLE_MUTCD, STYLE_VIENNA, STYLE_CANADA = 0, 1, 2
# speed_sign_mesh's material indices: white, red, metal, lettering, black (exit.materials.json's)
MATERIALS = ['bne_exit_white', 'bne_guide_red', 'bne_exit_metal', 'bne_guide_letters_black', 'bne_guide_black']
_lock = threading.Lock()


def posted(mph_value, mph=True):
    """The number on the sign of a limit of mph_value mph: mph (to 5) where mph are posted, else km/h (to 5); 0 for
    none."""
    if mph_value is None or not np.isfinite(mph_value) or mph_value <= 0:
        return 0.0
    v = mph_value if mph else mph_value * 1.609344
    return float(max(5, int(v / 5.0 + 0.5) * 5))


def style(country, us):
    """The sign face: MUTCD where a US state is (signstates), Canada's Rb-1, else the Vienna Convention's."""
    if us:
        return STYLE_MUTCD
    if (country or "").upper() == "CA":
        return STYLE_CANADA
    return STYLE_VIENNA


def _limits(feats, i, spec, mph):
    """[(fraction, posted value)] of feature i from 0 on: road_mph (the AI's) on each piece of its speed rules."""
    cuts = {0.0}
    table = feats.rules.get("max_speed_kmh")
    if table is not None:
        for r in table.rows(i):
            for f in (float(table.start[r]), float(table.end[r])):
                if 0.0 < f < 1.0:
                    cuts.add(round(f, 6))
    cuts = sorted(cuts) + [1.0]
    out = []
    for a, b in zip(cuts[:-1], cuts[1:]):
        v = posted(navgraph.road_mph(feats, i, spec, mph, at=(a + b) / 2), mph)
        if not out or out[-1][1] != v:
            out.append((a, v))
    return out


def _cell_rows(feats, frame, urban, widths, left_hand, mph):
    """{fid: (lon/lat line, xy line, meta [half width, dir, rank, urban, link], [(fraction, connector)],
    [(fraction, value)], [(start, end)] off the ground)} of a decoded map cell in frame (kept on the cell)."""
    key = (frame.lat0, frame.lon0, frame.h0, bool(left_hand), urban, widths, bool(mph))
    with _lock:
        memo = feats.__dict__.setdefault('_speed_rows', {})
        got = memo.get(key)
    if got is not None:
        return got
    specs = signroads.cell_specs(feats, urban, widths, left_hand)
    bspecs = roads.bridge_specs(feats)
    con = feats.rules.get("connectors")
    sub = feats.rules.get("subclass")
    picked, lines = [], []
    for i in range(len(feats)):
        sp = specs[i] if specs[i] is not None else bspecs[i]
        if sp is None or sp.cls not in navgraph.DRIVE or roads._rule_value(sub, i) in navgraph.SKIP_SUBCLASSES:
            continue
        parts = feats.parts(i)
        if not parts or not len(parts[0]) or len(parts[0][0]) < 2:
            continue
        picked.append((i, sp, specs[i] is None))
        lines.append(np.asarray(parts[0][0], np.float64)[:, :2])
    got = {}
    if picked:
        ll = np.concatenate(lines)
        e, n, _ = frame.geodetic_to_enu(ll[:, 1], ll[:, 0], 0.0)
        xy = np.column_stack([e, n])
        k = 0
        for (i, sp, bridge), line in zip(picked, lines):
            pts = xy[k:k + len(line)]
            k += len(line)
            cons = [(float(con.start[r]), str(con.value[r])) for r in con.rows(i)] if con is not None else []
            skips = [(0.0, 1.0)] if bridge else [(a, b) for a, b, _ in roads.level_ranges(feats, i)]
            meta = (sp.width / 2, (int(sp.dir) or 1) if sp.oneway else 0, RANK.get(sp.cls, 0),
                    1.0 if sp.urban else 0.0, 1.0 if getattr(sp, "link", False) else 0.0)
            got[str(feats.ids[i])] = (line, pts, meta, cons, _limits(feats, i, sp, mph), skips)
    with _lock:
        if len(memo) >= CELL_FRAMES:
            memo.pop(next(iter(memo)))
        memo[key] = got
    return got


def _arrays(rows, box):
    """speed_sign_place's road arrays of rows (each feature once) near box (x0, y0, x1, y1, MARGIN_M round it)."""
    x0, y0, x1, y1 = box
    ll, xy, off, meta = [], [], [0], []
    con_at, con_id, con_off = [], [], [0]
    lim_at, lim_val, lim_off = [], [], [0]
    skip, skip_off = [], [0]
    ids = {}
    for line, pts, m, cons, lims, skips in rows:
        if (pts[:, 0].max() < x0 - MARGIN_M or pts[:, 0].min() > x1 + MARGIN_M or
                pts[:, 1].max() < y0 - MARGIN_M or pts[:, 1].min() > y1 + MARGIN_M):
            continue
        ll.append(line)
        xy.append(pts)
        off.append(off[-1] + len(pts))
        meta.append(m)
        for f, c in cons:
            con_at.append(f)
            con_id.append(ids.setdefault(c, len(ids)))
        con_off.append(len(con_at))
        for f, v in lims:
            lim_at.append(f)
            lim_val.append(v)
        lim_off.append(len(lim_at))
        skip.extend(skips)
        skip_off.append(len(skip))
    if not xy:
        return None
    f64 = lambda a, *shape: np.ascontiguousarray(np.asarray(a, np.float64).reshape(*shape))    # noqa: E731
    i64 = lambda a: np.ascontiguousarray(np.asarray(a, np.int64))                              # noqa: E731
    return (f64(np.concatenate(xy), -1, 2), f64(np.concatenate(ll), -1, 2), i64(off), f64(meta, -1, 5),
            f64(con_at, -1), i64(con_id), i64(con_off), f64(lim_at, -1), f64(lim_val, -1), i64(lim_off),
            f64(skip, -1, 2), i64(skip_off))


def _outlines(pavements):
    """(points (n, 2), offsets) of the pavement outlines (kept on the signroads.Pavements)."""
    got = pavements.plans.get('speed_outlines')
    if got is None:
        polys = list(pavements.outlines or [])
        pts = np.concatenate(polys) if polys else np.zeros((0, 2))
        off = np.r_[0, np.cumsum([len(p) for p in polys])].astype(np.int64)
        got = pavements.plans['speed_outlines'] = (np.ascontiguousarray(pts[:, :2], np.float64), off)
    return got


def place(frame, box, context, left_hand=False, mph=True, face=STYLE_VIENNA):
    """The speed-limit signs of box (x0, y0, x1, y1): (k, 9) [x, y, travel x, travel y, value, size class, road x,
    road y, urban] (speed_sign_place's)."""
    fast.require(KERNEL, "speed-limit signs")
    x0, y0, x1, y1 = box
    m = MARGIN_M
    la, lo, _ = frame.enu_to_geodetic(np.array([x0 - m, x1 + m]), np.array([y0 - m, y1 + m]), 0.0)
    rows, seen = [], set()
    for key in mapcells.cells_for_bbox(float(la.min()), float(lo.min()), float(la.max()), float(lo.max())):
        feats = context.cell(key)
        if feats is None or not len(feats):
            continue
        for fid, row in _cell_rows(feats, frame, context.urban, context.widths, left_hand, mph).items():
            if fid not in seen:         # (a line is whole in every cell it crosses)
                seen.add(fid)
                rows.append(row)
    arrays = _arrays(rows, box)
    if arrays is None:
        return np.zeros((0, 9))
    cla, clo, _ = frame.enu_to_geodetic(np.array([x0, x1, x0, x1]), np.array([y0, y0, y1, y1]), 0.0)
    poly, poly_off = _outlines(context.pavements(frame, np.c_[clo, cla], left_hand))
    return fast._ef.speed_sign_place(*arrays, poly, poly_off, [float(v) for v in box], int(face), bool(left_hand),
                                     [float(v) for v in REPEAT_M])


@lru_cache(maxsize=1)
def _glyphs():
    data = exitsigns.lettering()
    chars = sorted(data['glyphs'])
    rows = [[g['advance'], *g['bbox'], *g['uv']] for g in (data['glyphs'][c] for c in chars)]
    return (np.array([ord(c) for c in chars], np.int64), np.ascontiguousarray(np.asarray(rows, np.float64)),
            float(data['capHeight']))


def build_tile(frame, tx, ty, elev, context, decks=(), left_hand=False, mph=True, face=STYLE_VIENNA):
    """The mesh (signstream.write_tile's) of road tile (tx, ty)'s speed-limit signs, or None (none)."""
    box = roads.tile_bbox(tx, ty)
    signs = place(frame, box, context, left_hand, mph, face)
    keep = [k for k in range(len(signs)) if not exitsigns._on_deck(signs[k, :2], decks, 1.5)]
    if not keep:
        return None
    signs = signs[keep]
    pts = np.vstack([signs[:, 0:2], signs[:, 6:8]])
    la, lo, _ = frame.enu_to_geodetic(pts[:, 0], pts[:, 1], 0.0)
    h = np.asarray(elev(la, lo), np.float64).ravel()
    z = np.asarray(frame.geodetic_to_enu(la, lo, h)[2], np.float64).ravel()
    n = len(signs)
    table = np.column_stack([signs[:, 0:2], z[:n], z[n:], signs[:, 2:4], signs[:, 4:6], signs[:, 8]])
    cp, glyph, cap = _glyphs()
    p, t, uv, mi = fast._ef.speed_sign_mesh(np.ascontiguousarray(table), int(face), cp, glyph, cap,
                                            [float(box[0]), float(box[1]), 0.0])
    if not len(t):
        return None
    return p, t, uv, MATERIALS, mi
