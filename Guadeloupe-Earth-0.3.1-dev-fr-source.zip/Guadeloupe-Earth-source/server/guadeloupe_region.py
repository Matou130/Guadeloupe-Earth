"""Geographic policy for the Guadeloupe Earth fork.

The current release uses a rectangular working envelope. This deliberately includes
near-shore water and inter-island sea so map/terrain tiles can meet cleanly. Replace
or refine it with an authoritative multipolygon before claiming a land-only cutout.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable

MOD_NAME = "Guadeloupe Earth"
MOD_VERSION = "0.2.2-dev"

@dataclass(frozen=True)
class Bounds:
    south: float
    west: float
    north: float
    east: float

    def contains(self, lat: float, lon: float) -> bool:
        return self.south <= lat <= self.north and self.west <= lon <= self.east

    def intersects(self, south: float, west: float, north: float, east: float) -> bool:
        return not (north < self.south or south > self.north or east < self.west or west > self.east)

# Working extent: Grande-Terre, Basse-Terre and nearby dependencies.
# This is a generation envelope, NOT an official administrative boundary polygon.
BOUNDS = Bounds(south=15.75, west=-61.95, north=16.60, east=-60.90)
# The menu map needs surrounding sea and nearby islands so its viewport does not end in a
# rectangular gray cutout. This is display-only; terrain, imagery and destinations still use BOUNDS.
MAP_TILE_BOUNDS = Bounds(south=15.25, west=-63.20, north=17.10, east=-60.00)
CENTRE = (16.175, -61.425)
CACHE_CAP_GB = 0  # cache.py: 0 means unlimited

SPAWN_POINTS = (
    {"id": "pointe_a_pitre", "name": "Pointe-à-Pitre", "lat": 16.2415, "lon": -61.5330},
    {"id": "basse_terre", "name": "Basse-Terre", "lat": 15.9970, "lon": -61.7290},
    {"id": "capesterre", "name": "Capesterre-Belle-Eau", "lat": 16.0450, "lon": -61.5650},
    {"id": "airport", "name": "Aéroport Pôle Caraïbes", "lat": 16.2650, "lon": -61.5310},
    {"id": "saint_francois", "name": "Saint-François", "lat": 16.2520, "lon": -61.2730},
    {"id": "deshaies", "name": "Deshaies", "lat": 16.3060, "lon": -61.7950},
    {"id": "grand_bourg", "name": "Grand-Bourg – Marie-Galante", "lat": 15.8830, "lon": -61.3150},
    {"id": "terre_de_haut", "name": "Terre-de-Haut – Les Saintes", "lat": 15.8670, "lon": -61.5830},
    {"id": "la_desirade", "name": "La Désirade", "lat": 16.3080, "lon": -61.0800},
)


def is_inside(lat: float, lon: float) -> bool:
    try:
        lat, lon = float(lat), float(lon)
    except (TypeError, ValueError, OverflowError):
        return False
    return math.isfinite(lat) and math.isfinite(lon) and -90 <= lat <= 90 and -180 <= lon <= 180 and BOUNDS.contains(lat, lon)


def require_inside(lat: float, lon: float) -> tuple[float, float]:
    lat, lon = float(lat), float(lon)
    if not is_inside(lat, lon):
        raise ValueError(
            f"coordinates outside {MOD_NAME} working extent "
            f"({BOUNDS.south}..{BOUNDS.north} N, {BOUNDS.west}..{BOUNDS.east} W)"
        )
    return lat, lon


def tile_bounds(z: int, x: int, y: int) -> tuple[float, float, float, float]:
    """Return (south, west, north, east) of an XYZ Web-Mercator tile."""
    z, x, y = int(z), int(x), int(y)
    if z < 0 or z > 30:
        raise ValueError("zoom outside supported range")
    n = 1 << z
    if not (0 <= x < n and 0 <= y < n):
        raise ValueError("tile outside world")

    def latitude(tile_y: int) -> float:
        return math.degrees(math.atan(math.sinh(math.pi * (1.0 - 2.0 * tile_y / n))))

    west = x / n * 360.0 - 180.0
    east = (x + 1) / n * 360.0 - 180.0
    north = latitude(y)
    south = latitude(y + 1)
    return south, west, north, east


def tile_intersects(z: int, x: int, y: int) -> bool:
    try:
        return BOUNDS.intersects(*tile_bounds(z, x, y))
    except (TypeError, ValueError, OverflowError):
        return False


def map_tile_intersects(z: int, x: int, y: int) -> bool:
    """Whether a map-menu tile overlaps the wider display extent (not the driveable world)."""
    try:
        return MAP_TILE_BOUNDS.intersects(*tile_bounds(z, x, y))
    except (TypeError, ValueError, OverflowError):
        return False


def filter_points(points: Iterable[dict]) -> list[dict]:
    """Keep geocoder-like records with finite in-region lat/lon fields."""
    out = []
    for point in points:
        if isinstance(point, dict) and is_inside(point.get("lat"), point.get("lon")):
            out.append(point)
    return out
